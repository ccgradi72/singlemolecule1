function [Amp, x0, y0, sigma, offset] = gauss(z)

[ny,nx] = size(z);  
[px,py] = meshgrid(1:nx,1:ny);   
[maxzy, maxzx] = find(z==max(z(:))); 

if size(maxzx,1)>1
   maxzx = ceil(nx/2);
   maxzy = ceil(ny/2);
end

if maxzx < 2, maxzx = 2; end
if maxzx > (nx-1), maxzx = nx-1; end
if maxzy <2, maxzy = 2; end
if maxzy > (ny-1), maxzy = ny-1; end
zc = z(maxzy-1:maxzy+1,maxzx-1:maxzx+1);

if max(abs(diff(zc(:))))>(100*eps)   
   zc = zc-min(zc(:));  
   pxc = px(maxzy-1:maxzy+1,maxzx-1:maxzx+1);
   pyc = py(maxzy-1:maxzy+1,maxzx-1:maxzx+1);
   sumzc = sum(zc(:));
   params0_2 = sum(sum(zc.*pxc))/sumzc;   
   params0_3 = sum(sum(zc.*pyc))/sumzc;   
else
   params0_2 = maxzx;  
   params0_3 = maxzy;  
end
params0 = [min(z(:)), params0_2, params0_3, min([nx ny])/4, max(z(:))-min(z(:))];
    

fminoptions.TolFun = 1e-6;  
fminoptions.TolX = 1e-6';  
fminoptions.Display = 'off'; 
fminoptions.LargeScale = 'off';  
   

params = fminunc(@(P) objfun(P,px,py,z),params0,fminoptions);
offset = params(1);
x0 = params(2);
y0 = params(3);
sigma = params(4);
Amp = params(5);


end

function negL = objfun(params,px,py,z)
    temp = [px(:) - params(2),py(:)-params(3)];
    temp2 = params(5)*exp(-sum(temp.*temp,2)/2/params(4)/params(4)) + params(1);
    Lk = (z(:)).*log(temp2) - temp2;
    negL = -sum(Lk(:));
end
    