function Rutenberg_simu
close all
PathName = uigetdir('Select a folder containing PB traces','C:\Users\Yuchong\Desktop\Server\Rutenberg\');
dt = 0.3 %input('Enter the frame rate (seconds per frame: \n)');
minimal_dI = 1; %input('Enter the minimal change in intensity for a photobleaching step: \n');
Crit = 7 %input ('Log-p value Criteria (Crit >=1.3,try 5-7, the higher the more strict): \n');

FileNames = dir([PathName '\*I_vs_t.txt']);
numParticles = numel(FileNames);
first_file = importdata([PathName '\' FileNames(1).name]);
numFrames = length(first_file(:,1));

inten_all = zeros(numFrames,numParticles);
parfor i=1:numParticles
    current_file = importdata([PathName '\' FileNames(i).name]);
    inten_all(:,i) = current_file(:,2);
end

analysis_save_directory = [PathName '\' 'change-point analysis results\'];
mkdir(analysis_save_directory);
Step_Intensity_all = [];
Step_Intensity_cleaned = [];
Init_Intensity = zeros(numParticles,1);
Num_Steps_all = zeros(numParticles,1);
Num_Steps_cleaned = zeros(numParticles,1);
Step_Duration = [];
Total_Duration = zeros(numParticles,1);
detection_logp = [];

%  hwait = waitbar(0,'analysis progress');

for i = 1:numParticles
%     waitbar(i/numParticles,hwait);
    current_traj = inten_all(:,i);        %this is the fluorescence intensity trajectory of current molecule
    bkgd = mean(current_traj(end-50:end));

    [CP_Plot, CP_all, CP_cleaned, CP_duration, CP_logp]=cponechannel(current_traj',bkgd,minimal_dI,Crit);
    %CP_Plot is the repeated changepoint t-I array, for plotting the step-like curve.
    %CP_all contains all of the detected changepoints' (t I). CP_cleaned has the unwanted changepoints removed.
    %CP_cleaned is what we want to work with.
    %unit for all CP intensities are counts per frame (not per second)
    
    Num_Steps_all(i) = length(CP_all(:,2))-1;
    Step_Intensity_all = [Step_Intensity_all; -diff(CP_all(:,2))/dt]; % These are all the individual step sizes.
    Num_Steps_cleaned(i) = length(CP_cleaned(:,2))-1;
    Step_Intensity_cleaned = [Step_Intensity_cleaned; -diff(CP_cleaned(:,2))/dt]; % These are the cleaned-up individual step sizes.
    Step_Duration = [Step_Duration; CP_duration*dt];
    Init_Intensity(i) = max(CP_all(:,2))/dt;
    Total_Duration(i) = sum(CP_duration);
    detection_logp = [detection_logp CP_logp];
    
    hf_current = figure;
    set(hf_current,'Visible', 'off');
    plot((1:numFrames)*dt,(current_traj-bkgd)/dt,'k');
    hold on
    plot(CP_Plot(:,1)*dt,CP_Plot(:,2)/dt,'r');
    xlabel('Time(sec)');
    ylabel('Counts per sec');
    legend([num2str(length(CP_cleaned(:,2))-1) ' steps detected']);
    set(hf_current,'color',[1 1 1])
    set(hf_current,'PaperPositionMode','auto')
    print([analysis_save_directory,'#',sprintf('%04d',i),'.png'],'-dpng','-r150')
    hold off
    
    dlmwrite([analysis_save_directory, 'traj_', num2str(i), '_CP_all.txt'],[CP_all(:,1).*dt CP_all(:,2)./dt],'\t'); 
    %column 1 is t of change point, column 2 is I at that t
    dlmwrite([analysis_save_directory, 'traj_', num2str(i), '_CP_cleaned.txt'],[CP_cleaned(:,1).*dt CP_cleaned(:,2)./dt],'\t');
end

save([analysis_save_directory 'CP results.mat'], 'FileNames','Step_Intensity_all', 'Step_Intensity_cleaned', 'Init_Intensity', ...
    'Num_Steps_all', 'Num_Steps_cleaned', 'Step_Duration', 'Total_Duration','detection_logp');

figure
hist(Num_Steps_cleaned,min(Num_Steps_cleaned):max(Num_Steps_cleaned));
axis tight
NumStepHist = hist(Num_Steps_cleaned,min(Num_Steps_cleaned):max(Num_Steps_cleaned));
NumStepHist = NumStepHist';
xlabel('Steps','FontSize',11);ylabel('Frequency','FontSize',11);
title('Number of Steps','FontSize',14);
dlmwrite([analysis_save_directory 'Hist_Num Steps.txt'],NumStepHist,'\t');

figure
hist(detection_logp);
axis tight
xlabel('-log p value','FontSize',11);ylabel('Frequency','FontSize',11);
title('Statistical Significance of Steps','FontSize',14);
end