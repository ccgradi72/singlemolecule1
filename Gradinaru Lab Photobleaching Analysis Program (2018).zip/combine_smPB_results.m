close all

[FileNames,PathName] = uigetfile('*.mat', 'Load smPB analysis mat output files','MultiSelect','on');
num_files = numel(FileNames);
FileNames'

Summary_Step_Intensity_cleaned = [];
Summary_Num_Steps_cleaned = [];
Summary_Step_Duration = [];
Summary_Init_Intensity = [];

for i=1:num_files
    load(FileNames{i}, 'Step_Intensity_all', 'Step_Intensity_cleaned', 'Init_Intensity', ...
        'Num_Steps_all', 'Num_Steps_cleaned', 'Step_Duration', 'Total_Duration', 'xy_map');
    Summary_Step_Intensity_cleaned = [Summary_Step_Intensity_cleaned; Step_Intensity_cleaned];
    Summary_Num_Steps_cleaned = [Summary_Num_Steps_cleaned; Num_Steps_cleaned];
    Summary_Step_Duration = [Summary_Step_Duration; Step_Duration];
    Summary_Init_Intensity = [Summary_Init_Intensity; Init_Intensity];
end

figure
histogram(Summary_Step_Intensity_cleaned,50);
axis tight
StepIntHist = histogram(Summary_Step_Intensity_cleaned,50);
xlabel('counts per sec','FontSize',11);ylabel('occurrence','FontSize',11);
title('Step-wise Intensity','FontSize',14);


figure
histogram(Summary_Num_Steps_cleaned,0:20);
axis tight
NumStepHist = histogram(Summary_Num_Steps_cleaned,'BinMethod','integers');
xlabel('Steps','FontSize',11);ylabel('occurrence','FontSize',11);
title('Number of Steps','FontSize',14);

figure
histogram(Summary_Step_Duration,50);
axis tight
StepDurHist = histogram(Summary_Step_Duration,50);
xlabel('sec','FontSize',11);ylabel('occurrence','FontSize',11);
title('Duration of steps','FontSize',14);

figure
histogram(Summary_Init_Intensity,50);
axis tight
InitIntenHist = histogram(Summary_Init_Intensity,50);
xlabel('cps','FontSize',11);ylabel('occurrence','FontSize',11);
title('Initial intensity','FontSize',14);