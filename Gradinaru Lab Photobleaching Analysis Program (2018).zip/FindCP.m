function [array_for_plotting,changepoint_all]=FindCP(tempc,minimal_dI,Crit1)

%   Data0 = tempc(:,1);  % there is only one column in tempc
   
    bg1 = tempc(end-100:end);
    background = mean(bg1);
    
    Data1=tempc-background; %Data1 is the fluorescence intensity trajectory with no background   
    Data1(Data1==0)=0.000001;

    CPsummary = [];
    Stepsummary = [];
    cumsum_array=cumsum(Data1); %cumulative sum of the intensity traj

changepoint_all=[1 0]; 
index1=1; 
CritLength=3; 

while (~isempty(index1))&&(length(Data1)>=CritLength) 
      
    Newcumsum_array=cumsum(Data1);
     
%   vector1=cpp(Newcumsum_array');  
 
    index1 = cptest(Data1,Newcumsum_array',Crit1);  %transpose of Newcumsum_array is needed because somehow the cptest.m requires a column array
    
      if ~isempty(index1) 
             
          changepoint_all(end+1,1)=changepoint_all(end,1)+index1; %the first column is the time point of change point
          changepoint_all(end,2)=cumsum_array(changepoint_all(end,1)); %the second column is an element from the cumulated sum, probably not the intensity level.
          Data1=Data1(index1+1:end);
             
      end 
        
 end 
 
changepoint_all(end+1,1) = length(cumsum_array); 
changepoint_all(end,2) = cumsum_array(changepoint_all(end,1));
     
[array_for_plotting , changepoint_all] = slopes(changepoint_all); 
%Starting after this command, 'changepoint_all' contains the intensity levels.

% changepoint_cleaned = changepoint_all(2:end,:);
% %for removing the unwanted spikes, rising edges, or shallow steps.
% %now moved to trajmaxg.m
% iter = length(changepoint_cleaned(:,2));
% j=1;
% while(j<iter)
%     if changepoint_cleaned(j+1,2) > changepoint_cleaned(j,2)-minimal_dI
%        changepoint_cleaned(j+1,:) = [];
%        iter = iter -1;
%     else
%         j=j+1;
%     end
% end
