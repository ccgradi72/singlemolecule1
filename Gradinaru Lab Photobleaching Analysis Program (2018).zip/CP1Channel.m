function [array_for_plotting, CP_all, CP_cleaned, duration_per_step, CP_logp]=CP1Channel(tempc,bkgd,minimal_dI,Crit1)

%   Data0 = tempc(:,1);  % there is only one column in tempc
       
    Data1=tempc-bkgd; %Data1 is the fluorescence intensity trajectory with no background   
    Data1(Data1==0)=0.000001;

    CPsummary = [];
    Stepsummary = [];
    cumsum_array=cumsum(Data1); %cumulative sum of the intensity traj

CP_all = [1 0]; 
CP_logp = [];
index1=1; %relative location of the first change point
CritLength=3; 

while (~isempty(index1))&&(length(Data1)>=CritLength) 
      
    Newcumsum_array=cumsum(Data1);
     
%   vector1=cpp(Newcumsum_array');  
 
    [index1, current_logp] = cptest_YL(Data1,Newcumsum_array',Crit1);  %transpose of Newcumsum_array is needed because somehow the cptest.m requires a column array
	    
      if ~isempty(index1) 
             
          CP_all(end+1,1)=CP_all(end,1)+index1; %the first column is the time point of change point
          CP_all(end,2)=cumsum_array(CP_all(end,1)); %the second column is an element from the cumulated sum, probably not the intensity level.
          Data1=Data1(index1+1:end);
          CP_logp=[CP_logp current_logp];
             
      end 
        
 end 
CP_all=CP_all(2:end,:); %remove the first row of [1 0] created by the initialization above
CP_all(end+1,1) = length(cumsum_array); 
CP_all(end,2) = cumsum_array(CP_all(end,1));
     
[array_for_plotting , CP_all] = slopes(CP_all); 
%Starting after this command, 'CP_all' contains the intensity levels.

CP_cleaned = CP_all;
timepoint_cleaned = CP_all(:,1);
%for removing the unwanted spikes, rising edges, or shallow steps.
%now moved to trajmaxg.m
iter = length(CP_cleaned(:,2));
j=1;
while(j<iter)
    if CP_cleaned(j+1,2) > CP_cleaned(j,2)-minimal_dI
       CP_cleaned(j+1,:) = [];
	   timepoint_cleaned(j+1) = [];
       iter = iter -1;
    else
        j=j+1;
    end
end
duration_per_step = diff([0; timepoint_cleaned]);