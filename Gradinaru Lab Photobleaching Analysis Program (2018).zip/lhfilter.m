function res = lhfilter(image,lobject,xdim,ydim)

normalize = @(x) x/sum(x);

lnoise = 1;
gaussian_kernel = normalize(exp(-((-lobject:lobject)/(2*lnoise)).^2));
boxcar_kernel = normalize(ones(1,length(-lobject:lobject)));


gconv = conv2(image',gaussian_kernel','same');
gconv = conv2(gconv',gaussian_kernel','same');

bconv = conv2(image',boxcar_kernel','same');
bconv = conv2(bconv',boxcar_kernel','same');

filtered = gconv - bconv;


filtered(1:lobject+1,:) = 0;
filtered((end - lobject):end,:) = 0;
filtered(:,1:lobject+1) = 0;
filtered(:,(end - lobject):end) = 0;

for i = 1:ydim
    for j = 1:xdim
        if filtered(i,j) < 0
            filtered(i,j) = 0;
        end
    end
end

res = filtered;

