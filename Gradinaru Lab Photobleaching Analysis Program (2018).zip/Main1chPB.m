function MainSMphotobleaching
% This program is designed for movie-based single-color single molecule photobleaching analysis 
% The movie data must be in TIFF format. 
% A uniform illumination field is highly preferred. 
% If the illumination is not uniform, you can use a short movie of a homogenouse dye solution as flattening calibration.
% The program automatically identifies particles, then record and analyze the intensity traces.
% The photobleach step determination algorithm is change-point analysis based on 
% Gallistel & Balsam et. al. "The learning curve: implications of a quantitative analysis." PNAS (2004)
% The analysis results will be saved as text file and png figures for visulization in the data folder
% For more information on the adjustment of parameters, please contact: 
% Yuchong Li: yuchong.li@utoronto.ca or Dr. Claudiu Gradinaru: claudiu.gradinaru@utoronto.ca.
% copyright (c) 2018 Yuchong Li

close all
rate = 100 %input('Exposure time per frame (unit: ms): \n');
molsize = 4 %input ('What is the expected diameter of your molecule in pixels?: \n'); % unit: pixel
flatten = 2 %input('Perform Flattening Calibration? 1) Yes, or 2) No: \n');
minimal_dI = 1; %input('Enter the minimal change in intensity for a photobleaching step (counts per frame): \n');
% minimal_dI is not necessary 
Crit = 7 %input ('Conifedience Criteria (Crit >=1.3,try 5-7): \n');

disp('To modify the values above, go to the main program.');

%% load stack file tiff format
[FileName,PathName] = uigetfile('*.*', 'Load Single Molecule Images');
fname = [PathName FileName(1:end-4)];
cd(PathName)
info = imfinfo(FileName);
numFrames = numel(info);
xdimen = info(1).Width;
ydimen = info(1).Height;
img = zeros (ydimen,xdimen);
for t = 1:20
    img = img + double(imread(FileName,t));
end
img = img/20;


% molecule size
filtimg = lhfilter(img,molsize,xdimen,ydimen);
ste = strel('disk', floor(molsize/2),0);
dimg = imdilate(filtimg, ste);

repick_threshold=1;
[hs, bins] = hist(filtimg(:),1000); %[nelements,xcenters] = hist(data)
ch1 = cumsum(hs);
ch = ch1/max(ch1);
ROI_radius = floor(molsize/2+1);
while repick_threshold==1
    % detection threshold
    threshold_lower = input('Enter the lower brightness percentile threshold  (try 0.97): '); %any dots that are brighter than this fraction of the max will be identified
%    threshold_upper = input('Enter the upper brightness percentile threshold  (try 0.999): ');
	withinthresh = find( (ch>threshold_lower)); % & (ch<threshold_upper));
    BW = (filtimg == dimg);
    [y, x] = find(BW & (filtimg > bins(withinthresh(1))));
    
    % Get rid of maxima too close to the edge
    edgeind = ((x < ROI_radius) | (x > (xdimen-ROI_radius))) | ((y < ROI_radius) | (y > (ydimen-ROI_radius)));
    x(edgeind) = [];
    y(edgeind) = [];
    
    % display detection
    imshow(img,[mean(min(img)),mean(max(img))]);
    hold on;
    plot(x,y,'ro','markersize', molsize,'MarkerEdgeColor','r');
    hold off;
    % print([fname,'_detection.png'],'-dpng','-r150');
    numParticles = length(x);
    disp(['Total detected number of molecules: ' num2str(numParticles)])
    
    repick_threshold=input('Press Enter to continue. Press 1 if you would like to RE-PICK the detection threshold: ');
    
end
%% use Gaussian fit
rect = zeros(numParticles, 4);
for k = 1:numParticles
    rect(k,:) = [round(x(k) - ROI_radius) round(y(k) - ROI_radius) 2*ROI_radius 2*ROI_radius];
    cropimg(:,:,k) = imcrop(img, rect(k,:));
end

xcent = zeros(1,numParticles);
ycent = zeros(1,numParticles);
sigma = zeros(1,numParticles);
for j = 1:numParticles
    [img, xcent(j), ycent(j), sigma(j), offset] = gauss(cropimg(:,:,j));
end

xn = round (xcent + rect(:,1)' - 1);
yn = round (ycent + rect(:,2)' - 1);

%% output trajectories and do change point analysis
imagestack = [];

for j = 1:numFrames
    currentImage = imread([fname '.tif'], j, 'Info', info);
    currentImage = im2double(currentImage)*(2^16);
    currentImage = uint16(currentImage);
    imagestack(:,:,j) = currentImage;
end

if flatten == 1
    [flatfile, flatpath] = uigetfile({'*.tif'},'Flatten Calibration File Selector');
    flatinfo = imfinfo(fullfile(flatpath,flatfile));
    flatxdim = flatinfo(1).Width;
    flatydim = flatinfo(1).Height;
    if (xdim~=flatxdim)||(ydim~=flatydim)
        disp('Flatten Calibration File size is incompatible with Raw File size');
    else
        flatcalibimage = imread(fullfile(flatpath,flatfile));
        flatcalibimage = im2double(flatcalibimage);
        
        flatmin = min(min(flatcalibimage));
        flatcalibrationimage2 = flatcalibimage -flatmin;
        flatmax = max(max(flatcalibrationimage2));
        flatnormalize = flatcalibrationimage2./flatmax;
        imagestack = im2double(imagestack);
        for j = 1:numFrames
            imagestack(:,:,j) = imagestack(:,:,j)./flatnormalize;
            imagestack(:,:,j) = uint16(imagestack(:,:,j));
        end
    end
end

IntenTraj_all = zeros(numParticles,numFrames);
for i = 1:numParticles
    ROI_left = max(xn(i)-ROI_radius,1);
    ROI_right = min(xn(i)+ROI_radius,xdimen);
    ROI_top = min(yn(i)+ROI_radius,ydimen);
    ROI_bottom = max(yn(i)-ROI_radius,1);
    for j = 1:numFrames
        brightest = sort(reshape( imagestack( ROI_bottom:ROI_top , ROI_left:ROI_right ,j) ,1,[]), 'descend');
        IntenTraj_all(i,j) = sum(brightest(1:4))/4;
        %for the jth frame, the program finds the brightest 4 pixels in a 7*7 region around the identified object
        %objects near the edge of the image have been removed in the main program.
%         ROI_particle = imagestack( ROI_bottom:ROI_top , ROI_left:ROI_right ,j);
%         IntenTraj(ind,j) = sum(sum(ROI_particle))/numel(ROI_particle);

    end
end

TrajAnalyze(fname,IntenTraj_all,xn,yn,numFrames,numParticles,rate,minimal_dI,Crit);
%trajmaxg(objs_pos,fname,xdimen,ydimen,NumFrame,rate,flatten,minimal_dI,Crit);

