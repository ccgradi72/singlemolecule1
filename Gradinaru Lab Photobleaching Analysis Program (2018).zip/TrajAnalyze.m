function []=TrajAnalyze(fname,inten_all,xn,yn,numFrames,numParticles,rate,minimal_dI,Crit)
% load('trajectories for analysis.mat')
% inten_all=intensity_traj;
xy_map=[xn' yn'];
Step_Intensity_all = [];
Step_Intensity_cleaned = [];
Init_Intensity = zeros(numParticles,1);
Num_Steps_all = zeros(numParticles,1);
Num_Steps_cleaned = zeros(numParticles,1);
Step_Duration = [];
Total_Duration = zeros(numParticles,1);
detection_confidence = [];

current_save_directory = [fname '\'];
mkdir(current_save_directory);
minimal_dI_frame = minimal_dI*rate/1000;

hwait = waitbar(0,'analysis progress');

for i = 1:numParticles
    waitbar(i/numParticles,hwait);    
    current_traj = inten_all(i,:);        %tempc is the fluorescence intensity trajectory of current molecule. Unit: counts per frame
    bkgd = mean(current_traj(end-50:end));
   
    [CP_Plot, CP_all, CP_cleaned, CP_duration, CP_logit]=CP1Channel(current_traj,bkgd,minimal_dI_frame,Crit);
    %CP_Plot is the repeated changepoint t-I array, for plotting the step-like curve.
    %CP_all contains all of the detected changepoints' (t I). CP_cleaned has the unwanted changepoints removed.
    %CP_cleaned is what we want to work with.
    
    Num_Steps_all(i) = length(CP_all(:,2))-1;
    Step_Intensity_all = [Step_Intensity_all; -diff(CP_all(:,2))*1000/rate]; % These are all the individual step sizes.
    Num_Steps_cleaned(i) = length(CP_cleaned(:,2))-1;
    Step_Intensity_cleaned = [Step_Intensity_cleaned; -diff(CP_cleaned(:,2))*1000/rate]; % These are the cleaned-up individual step sizes.
    Step_Duration = [Step_Duration; CP_duration*rate/1000];
    Init_Intensity(i) = max(CP_all(:,2))*1000/rate;
    Total_Duration(i) = sum(CP_duration);
    detection_confidence = [detection_confidence CP_logit];
    
    dlmwrite([current_save_directory, 'traj_', num2str(i), '.txt'],transpose(current_traj),'\t');
    %       dlmwrite([current_save_directory, 'cp_', num2str(i), '.txt'],transpose(CP_all),'\t');
    
    
    hf_current = figure;
    set(hf_current,'Visible', 'off');
    plot((1:numFrames)*rate/1000,(current_traj-bkgd)*1000/rate,'k');
    hold on
    plot(CP_Plot(:,1)*rate/1000,CP_Plot(:,2)*1000/rate,'r');
    xlabel('Time(sec)');
    ylabel('Counts per sec');
    title(['I-t Trajectory of Particle at ' num2str(xn(i)) num2str(yn(i))]);
    legend([num2str(length(CP_cleaned(:,2))-1) ' steps detected']);
    %        F=getframe(gcf);
    %        imwrite(F.cdata,[current_save_directory,'#',sprintf('%03d',i),'.png'])
    %	%	 GREG SAYS: getframe is notorious for memory leaks and memory hungriness - will avoid if possible
    set(hf_current,'color',[1 1 1])
    set(hf_current,'PaperPositionMode','auto')
    print([current_save_directory,'#',sprintf('%03d',i),'.png'],'-dpng','-r150')
    
    hold off
end
% dlmwrite([current_save_directory 'Step_Intensity_all.txt'],Step_Intensity_all,'\t');
% dlmwrite([current_save_directory 'Num_Steps_all.txt'],Num_Steps_all,'\t');
% dlmwrite([current_save_directory 'Step_Intensity_cleaned.txt'],Step_Intensity_cleaned,'\t');
% dlmwrite([current_save_directory 'Num_Steps_cleaned.txt'],Num_Steps_cleaned,'\t');
% dlmwrite([current_save_directory 'Step_Duration.txt'],Step_Duration,'\t');
% dlmwrite([current_save_directory 'XYMap.txt'],xy_map,'\t');
% dlmwrite([current_save_directory 'Init_Intensity.txt'],Init_Intensity,'\t');
% dlmwrite([current_save_directory 'Total_Duration.txt'],Total_Duration,'\t');
save([fname '.mat'], 'Step_Intensity_all', 'Step_Intensity_cleaned', 'Init_Intensity', ...
    'Num_Steps_all', 'Num_Steps_cleaned', 'Step_Duration', 'Total_Duration', 'xy_map');

figure
subplot(2,1,1)
hist(Step_Intensity_all,20);
xlabel('Counts per sec','FontSize',11);ylabel('Frequency','FontSize',11);
title('Step-wise Intensity','FontSize',14);
subplot(2,1,2)
hist(Num_Steps_all,0:10);
xlabel('Steps','FontSize',11);ylabel('Frequency','FontSize',11);
title('Num of Steps','FontSize',14);

figure
hist(Step_Intensity_cleaned,50);
axis tight
StepIntHist = hist(Step_Intensity_cleaned,20);
StepIntHist = StepIntHist';
xlabel('Counts per sec','FontSize',11);ylabel('Frequency','FontSize',11);
title('Step-wise Intensity','FontSize',14);
dlmwrite([current_save_directory 'Hist_Step Intensity.txt'],StepIntHist,'\t');


figure
hist(Num_Steps_cleaned,0:20);
axis tight
NumStepHist = hist(Num_Steps_cleaned,0:10);
NumStepHist = NumStepHist';
xlabel('Steps','FontSize',11);ylabel('Frequency','FontSize',11);
title('Number of Steps','FontSize',14);
dlmwrite([current_save_directory 'Hist_Num Steps.txt'],NumStepHist,'\t');

figure
hist(Step_Duration,50);
axis tight
StepDurHist = hist(Step_Duration,50);
StepDurHist = StepDurHist';
xlabel('sec','FontSize',11);ylabel('Frequency','FontSize',11);
title('Duration of steps','FontSize',14);
dlmwrite([current_save_directory 'Hist_Step Duration.txt'],StepDurHist,'\t');

figure
hist(Init_Intensity,50);
axis tight
InitIntenHist = hist(Init_Intensity,50);
InitIntenHist = InitIntenHist';
xlabel('cps','FontSize',11);ylabel('Frequency','FontSize',11);
title('Initial intensity','FontSize',14);
dlmwrite([current_save_directory 'Hist_Init Intensity.txt'],InitIntenHist,'\t');

close (hwait)