function [modelParam,stdp,dep,redchi,residual,logEntry] = FCSModelsThreeCurve(x,FCS,STD,modelParam0,fixParam,xpos1,xpos2,lsqOpt,nparam,lb,ub,model)
% This m-file contains all the available FCS fitting models.
% To add a new model, you have to add the model specifications both to this m-file, 
% and to the main function FCSFitterThreeCurve.m in order for the main program to
% create the corresponding fitted plots

warning('off','all')
%   modelParam0 - vector of initial guesses
%   fixParam - logical vector of which parameters to fix
%   xpos1:xpos2 - fitting range for chi sq minimization
%   lsqOpt - options for lsqnonlin

%   nparam - cell array containing the number of paramters in each model

%Set options for solver
%lsqOpt=[handles.maxiter handles.maxfunevals handles.tolfun handles.tolx];
options=optimset('MaxIter',lsqOpt(1),'MaxFunEvals',lsqOpt(2),'TolFun',lsqOpt(3),'TolX',lsqOpt(4),'Algorithm','levenberg-marquardt');

% if nnz(~isnan(STD))==0
%     %this is the case where STD is all NaN
%     %perform coded
%     disp('all NAN')
%     STD=ones(1,length(STD)); %replace all NaNs with ones
% end

%the "heart" of the solver
if model==1 %user chose crosscorr 3d anom    
    if ~isempty(ub)||~isempty(lb)
        %if there are any upper or lower bounds, use them
        [modelParam,resnorm,residual,exitflag,output,lambda,jacobian]=lsqnonlin(@objfcnCrossCor3DA,modelParam0,lb,ub,options);
    else
        %only able to use levenberg-marquadt if lb and ub are empty AND you can't just have symbol ub, lb you really need to use [] []
        [modelParam,resnorm,residual,exitflag,output,lambda,jacobian]=lsqnonlin(@objfcnCrossCor3DA,modelParam0,[],[],options);
    end
elseif model==2 %user chose crosscorr 2d anom
    if ~isempty(ub)||~isempty(lb)
        %if there are any upper or lower bounds, use them
        [modelParam,resnorm,residual,exitflag,output,lambda,jacobian]=lsqnonlin(@objfcnCrossCor2DA,modelParam0,lb,ub,options);
    else
        %only able to use levenberg-marquadt if lb and ub are empty AND you can't just have symbol ub, lb you really need to use [] []
        [modelParam,resnorm,residual,exitflag,output,lambda,jacobian]=lsqnonlin(@objfcnCrossCor2DA,modelParam0,[],[],options);
    end
elseif model==3 %user chose crosscorr 3d 2comp anom
    if ~isempty(ub)||~isempty(lb)
        %if there are any upper or lower bounds, use them
        [modelParam,resnorm,residual,exitflag,output,lambda,jacobian]=lsqnonlin(@objfcnCrossCor3DA2comp,modelParam0,lb,ub,options);
    else
        %only able to use levenberg-marquadt if lb and ub are empty AND you can't just have symbol ub, lb you really need to use [] []
        [modelParam,resnorm,residual,exitflag,output,lambda,jacobian]=lsqnonlin(@objfcnCrossCor3DA2comp,modelParam0,[],[],options);
    end
elseif model==4 %user chose crosscorr 2d 2comp anom
    if ~isempty(ub)||~isempty(lb)
        %if there are any upper or lower bounds, use them
        [modelParam,resnorm,residual,exitflag,output,lambda,jacobian]=lsqnonlin(@objfcnCrossCor2DA2Comp,modelParam0,lb,ub,options);
    else
        %only able to use levenberg-marquadt if lb and ub are empty AND you can't just have symbol ub, lb you really need to use [] []
        [modelParam,resnorm,residual,exitflag,output,lambda,jacobian]=lsqnonlin(@objfcnCrossCor2DA2Comp,modelParam0,[],[],options);
    end
elseif model==5 %user chose 3d 2comp anom sharing D2
    if ~isempty(ub)||~isempty(lb)
        %if there are any upper or lower bounds, use them
        [modelParam,resnorm,residual,exitflag,output,lambda,jacobian]=lsqnonlin(@objfcnCrossCor3DA2compShareD2,modelParam0,lb,ub,options);
    else
        %only able to use levenberg-marquadt if lb and ub are empty AND you can't just have symbol ub, lb you really need to use [] []
        [modelParam,resnorm,residual,exitflag,output,lambda,jacobian]=lsqnonlin(@objfcnCrossCor3DA2compShareD2,modelParam0,[],[],options);
    end
elseif model==6 %user chose 3d 2comp anom sharing D1 and D2
    if ~isempty(ub)||~isempty(lb)
        %if there are any upper or lower bounds, use them
        [modelParam,resnorm,residual,exitflag,output,lambda,jacobian]=lsqnonlin(@objfcnCrossCor3DA2compShareD1D2,modelParam0,lb,ub,options);
    else
        %only able to use levenberg-marquadt if lb and ub are empty AND you can't just have symbol ub, lb you really need to use [] []
        [modelParam,resnorm,residual,exitflag,output,lambda,jacobian]=lsqnonlin(@objfcnCrossCor3DA2compShareD1D2,modelParam0,[],[],options);
    end
end

%errors of fit
dof = length(residual)-nparam;
redchi=resnorm/dof;
Jacobianf=full(jacobian); %lsqnonlin returns  Jacobian as sparse matrix
Jacobianf(:,fixParam)=[]; %the columns corresponding to fixed parameters should be deleted to avoid singular Jacobian inverse problem
varp=resnorm*((Jacobianf'*Jacobianf)^-1)/dof;
stdp=sqrt(diag(varp));

cinv=diag(varp^-1);
c=diag(varp);

dep=1-(1./cinv.*c);%if eqn is overparameterized a mutual dependency exists
%values close to 1 indicate strong dependnency
dep=dep';
%if some parameters are fixed, must rewritre stdp vector
ind=find(fixParam); % eg, fixp= [1 0 0 0 1 0 1] Rinf and bgx fixed at zero
% ind =[1,5,7]
%stdp=[2 3 4 6] but should be [0 2 3 4 0 6 0]
stdp=stdp';
if ~isempty(ind)
    for i=1:nnz(fixParam) %three iterations in this example
        if ind(i)==1
            stdp=[0 stdp]; %=[0 2 3 4 6] on iteration 1
            dep=[0 dep];
        elseif ind(i)==length(fixParam)
            stdp=[stdp 0]; %=[0 2 3 4 0 6 0]
            dep=[dep 0];
        else
            stdp=[stdp(1:ind(i)-1) 0 stdp(ind(i):end)];
            %=[1 2 3 4 0 6] on iteration 2
            dep=[dep(1:ind(i)-1) 0 dep(ind(i):end)];
        end
    end
end


str=sprintf('The dof = %f = length residual %f - number of parameters %f + number of fixed parameters %f',dof,length(residual),length(modelParam),nnz(fixParam));

str1 = ['Reduced ChiSq is ',num2str(redchi),'.'];
logEntry=sprintf('%s \r\n \r\n %s \r\n \r\n %s \r\n \r\n %s',output.message,output.algorithm,str,str1);


%% objective functions for solver to solver
%     function [myfun]=objfcnCrossCor(modelParam)
%         
%         %modelParam0=[G0 w s D Tt Tf ginf];
%         
%         %fix certain parameters based on fixParam
%         %Eg fixParam=[0 0 0 1 0] would fix the fourth element of modelParam
%         %at the value given by the 4th value of modelParam0.
%         %eg: a= [1 2 3 4] b=[5 6 7 8] c=[0 1 0 1] c=logical(c)
%         % then a(c)=b(c) ---> a=[1 6 3 8]
%         %modelParam(fixParam)=modelParam0(fixParam);
%         
%         %Assign Parameters
%         G0=modelParam(1:3);
%         w=modelParam(4:6);
%         s=modelParam(7:9);
%         D=modelParam(10:12);
%         Tt=modelParam(13:15);
%         Tf=modelParam(16:18);
%         ginf=modelParam(19:21);
%         
%         myModel=[];
%         for j=1:length(G0)
%         diffxy=(1+x*(10^8)*4*D(j)/(w(j)^2)).^(-1);
%         diffz=(1+x*(10^8)*4*D(j)/(w(j)^2)/(s(j)^2)).^(-0.5);
%         trip1=1+(Tf(j)/(1-Tf(j))).*exp(-x*(10^6)/Tt(j));
%         myModel=[myModel (G0(j)*diffxy.*diffz.*trip1+ginf(j))];
%         end
%          
%         %size(myModel)
%         %size(FCS)
%         %size(STD)
%         
%         wx=1./(STD); %weight each by variance, which is STD squared
%         myfun=(FCS-myModel).*wx;
%         xpos3=length(x)+xpos1;
%         xpos4=length(x)+xpos2;
%         xpos5=2*length(x)+xpos1;
%         xpos6=2*length(x)+xpos2;
%         myfun=myfun([xpos1:xpos2 xpos3:xpos4 xpos5:xpos6]);
%         myfun(isnan(myfun))=0;
%         myfun(isinf(myfun))=0;
%     end

 function [myfun]=objfcnCrossCor2DA(modelParam)
        
        %modelParam0=[G0 w s D a Tt Tf ginf];
        
        %fix certain parameters based on fixParam
        %Eg fixParam=[0 0 0 1 0] would fix the fourth element of modelParam
        %at the value given by the 4th value of modelParam0.
        %eg: a= [1 2 3 4] b=[5 6 7 8] c=[0 1 0 1] c=logical(c)
        % then a(c)=b(c) ---> a=[1 6 3 8]
        %modelParam(fixParam)=modelParam0(fixParam);
        
        %Assign Parameters
        G0=modelParam(1:3);
        w=modelParam(4:6);
        s=modelParam(7:9);
        D=modelParam(10:12);
        a=modelParam(13);
        Tt=modelParam(14:16);
        Tf=modelParam(17:19);
        ginf=modelParam(20:22);
        
		myModel=[];
		for j=1:length(G0)
		diffxa=(1+ (x*(10^8)*4*D(j)/(w(j)^2)).^a ).^(-0.5);
        diffyza=(1+ (x*(10^8)*4*D(j)/(w(j)^2)/s(j)^2).^a ).^(-0.5);
        trip1=(1+(Tf(j)/(1-Tf(j))).*exp(-x*(10^6)/Tt(j)));
        myModel=[myModel (G0(j)*diffxa.*diffyza.*trip1+ginf(j))]; 
		end
		
        wx=1./(STD); %weight each by variance, which is STD squared 
        myfun=(FCS-myModel).*wx;
		xpos3=length(x)+xpos1;
        xpos4=length(x)+xpos2;
        xpos5=2*length(x)+xpos1;
        xpos6=2*length(x)+xpos2;
        myfun=myfun([xpos1:xpos2 xpos3:xpos4 xpos5:xpos6]);
        myfun(isnan(myfun))=0;
        myfun(isinf(myfun))=0;
 end

function [myfun]=objfcnCrossCor3DA(modelParam)
        
        %modelParam0=[G0 w s D a Tt Tf ginf];
        
        %fix certain parameters based on fixParam
        %Eg fixParam=[0 0 0 1 0] would fix the fourth element of modelParam
        %at the value given by the 4th value of modelParam0.
        %eg: a= [1 2 3 4] b=[5 6 7 8] c=[0 1 0 1] c=logical(c)
        % then a(c)=b(c) ---> a=[1 6 3 8]
        %modelParam(fixParam)=modelParam0(fixParam);
        
        %Assign Parameters
        G0=modelParam(1:3);
        w=modelParam(4:6);
        s=modelParam(7:9);
        D=modelParam(10:12);
        a=modelParam(13);
        Tt=modelParam(14:16);
        Tf=modelParam(17:19);
        ginf=modelParam(20:22);
        
		myModel=[];
		for j=1:length(G0)
		diffxya=(1+ (x*(10^8)*4*D(j)/(w(j)^2)).^a ).^(-1);
        diffza=(1+ (x*(10^8)*4*D(j)/(w(j)^2)/s(j)^2).^a ).^(-0.5);
        trip1=(1+(Tf(j)/(1-Tf(j))).*exp(-x*(10^6)/Tt(j)));
        myModel=[myModel (G0(j)*diffxya.*diffza.*trip1+ginf(j))]; 
		end
		
        wx=1./(STD); %weight each by variance, which is STD squared 
        myfun=(FCS-myModel).*wx;
		xpos3=length(x)+xpos1;
        xpos4=length(x)+xpos2;
        xpos5=2*length(x)+xpos1;
        xpos6=2*length(x)+xpos2;
        myfun=myfun([xpos1:xpos2 xpos3:xpos4 xpos5:xpos6]);
        myfun(isnan(myfun))=0;
        myfun(isinf(myfun))=0;
end

function [myfun]=objfcnCrossCor2DA2Comp(modelParam)
        
        %    modelParam0=[G0 w s frac1 D D2 a Tt Tf ginf];
        
        %fix certain parameters based on fixParam
        %Eg fixParam=[0 0 0 1 0] would fix the fourth element of modelParam
        %at the value given by the 4th value of modelParam0.
        %eg: a= [1 2 3 4] b=[5 6 7 8] c=[0 1 0 1] c=logical(c)
        % then a(c)=b(c) ---> a=[1 6 3 8]
        %modelParam(fixParam)=modelParam0(fixParam);
        
        %Assign Parameters
        G0=modelParam(1:3);
        w=modelParam(4:6);
        s=modelParam(7:9);
        frac1=modelParam(10:12);
        D=modelParam(13:15);
        D2=modelParam(16:18);
        a=modelParam(19);
        Tt=modelParam(20:22);
        Tf=modelParam(23:25);
        ginf=modelParam(26:28);
        
		myModel=[];
		for j=1:length(G0)
		diff1xa=(1+ (x*(10^8)*4*D(j)/(w(j)^2)).^a ).^(-0.5);
        diff1yza=(1+ (x*(10^8)*4*D(j)/(w(j)^2)/s(j)^2).^a ).^(-0.5);
		diff2xa=(1+ (x*(10^8)*4*D2(j)/(w(j)^2)).^a ).^(-0.5);
        diff2yza=(1+ (x*(10^8)*4*D2(j)/(w(j)^2)/s(j)^2).^a ).^(-0.5);
        trip1=(1+(Tf(j)/(1-Tf(j))).*exp(-x*(10^6)/Tt(j)));
        myModel=[myModel (G0(j) * ((frac1(j)*diff1xa.*diff1yza)+((1-frac1(j))*diff2xa.*diff2yza)) .*trip1 + ginf(j)) ]; 
		end
		
        wx=1./(STD); %weight each by variance, which is STD squared 
        myfun=(FCS-myModel).*wx;
		xpos3=length(x)+xpos1;
        xpos4=length(x)+xpos2;
        xpos5=2*length(x)+xpos1;
        xpos6=2*length(x)+xpos2;
        myfun=myfun([xpos1:xpos2 xpos3:xpos4 xpos5:xpos6]);
        myfun(isnan(myfun))=0;
        myfun(isinf(myfun))=0;
end

function [myfun]=objfcnCrossCor3DA2comp(modelParam)
        
        %modelParam0=[molar w s td Tr tt Tr2 tt2 ginf];
        
        %fix certain parameters based on fixParam
        %Eg fixParam=[0 0 0 1 0] would fix the fourth element of modelParam
        %at the value given by the 4th value of modelParam0.
        %eg: a= [1 2 3 4] b=[5 6 7 8] c=[0 1 0 1] c=logical(c)
        % then a(c)=b(c) ---> a=[1 6 3 8]
        %modelParam(fixParam)=modelParam0(fixParam);
        %modelParam( repmat(shareParam,1,3) ) = repmat( modelParam(shareParam), 1,3);
        %Assign Parameters
        G0=modelParam(1:3);
        w=modelParam(4:6);
        s=modelParam(7:9);
        frac1=modelParam(10:12);
        D=modelParam(13:15);
        D2=modelParam(16:18);
        a=modelParam(19);
        Tt=modelParam(20:22);
        Tf=modelParam(23:25);
        ginf=modelParam(26:28);
        
%        D2(1)=D2(3);  D2(2)=D2(3);
      
		myModel=[];
		for j=1:length(G0)
		diff1xya=(1+ (x*(10^8)*4*D(j)/(w(j)^2)).^a ).^(-1);
        diff1za=(1+ (x*(10^8)*4*D(j)/(w(j)^2)/s(j)^2).^a ).^(-0.5);
		diff2xya=(1+ (x*(10^8)*4*D2(j)/(w(j)^2)).^a ).^(-1);
        diff2za=(1+ (x*(10^8)*4*D2(j)/(w(j)^2)/s(j)^2).^a ).^(-0.5);
        trip1=(1+(Tf(j)/(1-Tf(j))).*exp(-x*(10^6)/Tt(j)));
        myModel=[myModel (G0(j)* ((frac1(j)*diff1xya.*diff1za)+((1-frac1(j))*diff2xya.*diff2za)).*trip1 + ginf(j))]; 
		end
		
        wx=1./(STD); %weight each by variance, which is STD squared 
        myfun=(FCS-myModel).*wx;
		xpos3=length(x)+xpos1;
        xpos4=length(x)+xpos2;
        xpos5=2*length(x)+xpos1;
        xpos6=2*length(x)+xpos2;
        myfun=myfun([xpos1:xpos2 xpos3:xpos4 xpos5:xpos6]);
        myfun(isnan(myfun))=0;
        myfun(isinf(myfun))=0;
        
%         if 1
%            subplot(3,1,1)
%              semilogx(x(xpos1:xpos2),FCS(xpos1:xpos2),'*r','LineWidth',2);
%            subplot(3,1,2)
%             semilogx(x(xpos1:xpos2),myModel(xpos1:xpos2),'-r','LineWidth',2);
%             subplot(3,1,3)
%             semilogx(x(xpos1:xpos2),myfun(xpos1:xpos2),'-r','LineWidth',2);
%            drawnow
%         end
        
    end

function [myfun]=objfcnCrossCor3DA2compShareD2(modelParam)
        
        %modelParam0=[molar w s td Tr tt Tr2 tt2 ginf];
        
        %fix certain parameters based on fixParam
        %Eg fixParam=[0 0 0 1 0] would fix the fourth element of modelParam
        %at the value given by the 4th value of modelParam0.
        %eg: a= [1 2 3 4] b=[5 6 7 8] c=[0 1 0 1] c=logical(c)
        % then a(c)=b(c) ---> a=[1 6 3 8]
        %modelParam(fixParam)=modelParam0(fixParam);
        %modelParam( repmat(shareParam,1,3) ) = repmat( modelParam(shareParam), 1,3);
        %Assign Parameters
        G0=modelParam(1:3);
        w=modelParam(4:6);
        s=modelParam(7:9);
        frac1=modelParam(10:12);
        D=modelParam(13:15);
        D2=modelParam(16);
        a=modelParam(17);
        Tt=modelParam(18:20);
        Tf=modelParam(21:23);
        ginf=modelParam(24:26);
      
		myModel=[];
		for j=1:length(G0)
		diff1xya=(1+ (x*(10^8)*4*D(j)/(w(j)^2)).^a ).^(-1);
        diff1za=(1+ (x*(10^8)*4*D(j)/(w(j)^2)/s(j)^2).^a ).^(-0.5);
		diff2xya=(1+ (x*(10^8)*4*D2/(w(j)^2)).^a ).^(-1);
        diff2za=(1+ (x*(10^8)*4*D2/(w(j)^2)/s(j)^2).^a ).^(-0.5);
        trip1=(1+(Tf(j)/(1-Tf(j))).*exp(-x*(10^6)/Tt(j)));
        myModel=[myModel (G0(j)* ((frac1(j)*diff1xya.*diff1za)+((1-frac1(j))*diff2xya.*diff2za)).*trip1 + ginf(j))]; 
		end
		
        wx=1./(STD); %weight each by variance, which is STD squared 
        myfun=(FCS-myModel).*wx;
		xpos3=length(x)+xpos1;
        xpos4=length(x)+xpos2;
        xpos5=2*length(x)+xpos1;
        xpos6=2*length(x)+xpos2;
        myfun=myfun([xpos1:xpos2 xpos3:xpos4 xpos5:xpos6]);
        myfun(isnan(myfun))=0;
        myfun(isinf(myfun))=0;
end

function [myfun]=objfcnCrossCor3DA2compShareD1D2(modelParam)
        
        %modelParam0=[molar w s td Tr tt Tr2 tt2 ginf];
        
        %fix certain parameters based on fixParam
        %Eg fixParam=[0 0 0 1 0] would fix the fourth element of modelParam
        %at the value given by the 4th value of modelParam0.
        %eg: a= [1 2 3 4] b=[5 6 7 8] c=[0 1 0 1] c=logical(c)
        % then a(c)=b(c) ---> a=[1 6 3 8]
        %modelParam(fixParam)=modelParam0(fixParam);
        %modelParam( repmat(shareParam,1,3) ) = repmat( modelParam(shareParam), 1,3);
        %Assign Parameters
        G0=modelParam(1:3);
        w=modelParam(4:6);
        s=modelParam(7:9);
        frac1=modelParam(10:12);
        D=modelParam(13);
        D2=modelParam(14);
        a=modelParam(15);
        Tt=modelParam(16:18);
        Tf=modelParam(19:21);
        ginf=modelParam(22:24);
      
		myModel=[];
		for j=1:length(G0)
		diff1xya=(1+ (x*(10^8)*4*D/(w(j)^2)).^a ).^(-1);
        diff1za=(1+ (x*(10^8)*4*D/(w(j)^2)/s(j)^2).^a ).^(-0.5);
		diff2xya=(1+ (x*(10^8)*4*D2/(w(j)^2)).^a ).^(-1);
        diff2za=(1+ (x*(10^8)*4*D2/(w(j)^2)/s(j)^2).^a ).^(-0.5);
        trip1=(1+(Tf(j)/(1-Tf(j))).*exp(-x*(10^6)/Tt(j)));
        myModel=[myModel (G0(j)* ((frac1(j)*diff1xya.*diff1za)+((1-frac1(j))*diff2xya.*diff2za)).*trip1 + ginf(j))]; 
		end
		
        wx=1./(STD); %weight each by variance, which is STD squared 
        myfun=(FCS-myModel).*wx;
		xpos3=length(x)+xpos1;
        xpos4=length(x)+xpos2;
        xpos5=2*length(x)+xpos1;
        xpos6=2*length(x)+xpos2;
        myfun=myfun([xpos1:xpos2 xpos3:xpos4 xpos5:xpos6]);
        myfun(isnan(myfun))=0;
        myfun(isinf(myfun))=0;
    end
end

