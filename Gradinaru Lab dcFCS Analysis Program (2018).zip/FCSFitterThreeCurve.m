function [ output_args ] = FCSFitterThreeCurve(varargin)
% This program performs global fitting on the three FCS curves from a single dcFCS measurement to a given model
% The data file must include at least one column of delay-time-axis, and three columns of correlation curves namely
% green auto-correlation, red auto-correlation, and cross-correlation.
% If your data contains the standard deviation of each time point, choose 'DcFCS' as the data source, otherwise
% you can choose 'individual FCS' as the data source.
% FCS fitting initializes automatically. You may select which parameters to fix, then close window to proceed.
% You may want to modify the code directly if you want to speed up the parameter fixation procedure.
% Output of the program includes a figure plotting the fitted curves, a text file containing the fitting parameters, and
% a .mat file containing other available variables that are used in the fitting process (lines 361~444 of this file). 
% For more information about the operation of the program, please contact by email: 
% Yuchong Li: yuchong.li@utoronto.ca or Dr. Claudiu Gradinaru: claudiu.gradinaru@utoronto.ca
% copyright (c) 2018 Yuchong Li

%% Preamble
 close all;


disp('-------------------------------------------------------------')

disp('-------------------------------------------------------------')

disp('----------------Fitting new file -------------------')

disp('-------------------------------------------------------------')

try
    equipmentID=varargin{4};
    if equipmentID==1
        disp('dcFCS File Source Selected')
    elseif equipmentID==2
        disp('sm-MPF File Source Selected')
    elseif equipmentID==3
        disp('sm-MPF File Source Selected')
    else
        disp('Error: Not a valid file source')
    end
catch
    %user must choose equipment
    % Construct a questdlg with three options
    choice = questdlg('Choose data source', ...
        'Data Source', ...
        'DcFCS','SM-MPF','individual FCS','individual FCS');
    % Handle response
    switch choice
        case 'DcFCS' %You should choose this if you want to fit combined data from MaRS
            disp([choice ' Selected'])
            equipmentID = 1;
        case 'SM-MPF'
            disp([choice ' Selected'])
            equipmentID = 2;
        case 'individual FCS'
            disp([choice ' Selected'])
            equipmentID = 3;
    end
end

%text reading

prompt={'Green Autocorr Column:',...
    'Green Std column:', 'Red Autocorr Column:', 'Red Std Column:','Crosscorr Column:', 'Cross Std Column:'};

try
    choice_channels = varargin{8};
catch
    if equipmentID==1 %dcFCS data
        %format = repmat('%f', [1 9]); %format for textscan for how many columns, user can change in ui.
        %hl=0; %header lines in textfiles
        %Yuchong: 'importdata' func does not need specifying format or headerlines
        name='Correlation Channel Selection';
        numlines=1;
        defaultanswer={'2','6','3','7','4','8'};
        choice_channels=inputdlg(prompt,name,numlines,defaultanswer);
    elseif equipmentID==2 %confocal data
        %format = repmat('%f', [1 8]); %format for textscan for how many columns, user can change in ui.
        %hl=0; %header lines in textfiles
        
        name='Correlation Channel Selection';
        numlines=1;
        defaultanswer={'2','3','4','5','6','7'};
        choice_channels=inputdlg(prompt,name,numlines,defaultanswer);
    elseif equipmentID==3 %MaRS data
        %format = repmat('%f', [1 6]); %format for textscan for how many columns, user can change in ui.
        %hl=2; %header lines in textfiles
        
        name='Correlation Channel Selection';
        numlines=1;
        defaultanswer={'4','1','6','1','2','1'};
        choice_channels=inputdlg(prompt,name,numlines,defaultanswer);
    end
end

FCS_col1 = str2num(choice_channels{1});
STD_col1 = str2num(choice_channels{2}); %useless for uncombined MaRS data.
FCS_col2 = str2num(choice_channels{3});
STD_col2 = str2num(choice_channels{4});
FCS_col3 = str2num(choice_channels{5});
STD_col3 = str2num(choice_channels{6});
    
%Plotting
lwthick=1.5;
lwthin=1;
nhistbin=50; %for residual plot
nr=-1; %round residuals plot ticks to power of 10^n

%% Load Data
try
    [FileName,PathName] = uigetfile('*.txt;*.dat','Select the data file',varargin{3}); %vargin{3} should be pathname from calibration call
catch
    [FileName,PathName] = uigetfile('*.txt;*.dat','Select the data file','D:\Dropbox\Work\');
end
%To replace with a permament location of text file:
%Example: PathName='E:\May 22 Data\';
%Example:FileName='IRF.txt';

disp('Now analyzing:')
disp(FileName)

% Read the file into matrix
DATA = importdata(fullfile(PathName,FileName));
if isstruct(DATA) %importing MaRS data yields a struct
    HeaderText=DATA.colheaders;
    DATA=DATA.data;
end
%close(fid)
t=DATA(:,1); %A
t=t';

    y_green=DATA(:,FCS_col1);
    y_red=DATA(:,FCS_col2);
    y_cross=DATA(:,FCS_col3);
    %ySTD_cross=sqrt(abs(y_cross)+eps(y_cross));
    
    stand_alone_STD = []; % for in cell data, where individual STD is impractical
    
    try
        std_method = varargin{6};
        if length(std_method)<3
        std_method=questdlg('How would you like to weigh the FCS?','Choose weight function',...
            'column in file', 'sliding window STD', 'stand-alone STD' , 'sliding window STD');
        end
    catch
        std_method=questdlg('How would you like to weigh the FCS?','Choose weight function',...
            'column in file', 'sliding window STD', 'stand-alone STD' , 'sliding window STD');
    end 
        
    switch std_method
         case 'column in file'
            ySTD_green=DATA(:,STD_col1);
            ySTD_red=DATA(:,STD_col2);
            ySTD_cross=DATA(:,STD_col3);
            
        case 'stand-alone STD'
            try
                stand_alone_STD = varargin{7}; %use the same population averaged weighting for all curves
                ySTD_green = stand_alone_STD(:,1);
                ySTD_red = stand_alone_STD(:,2);
                ySTD_cross = stand_alone_STD(:,3);
            catch
                [STDname,STDpath] = uigetfile('*.txt','Select the file containing std', 'D:\Dropbox\Work\wtgdt\RG\');
                STDreadout = importdata(fullfile(STDpath,STDname));
                ySTD_green = STDreadout(:,5);
                ySTD_red = STDreadout(:,6);
                ySTD_cross = STDreadout(:,7);
                stand_alone_STD = [ySTD_green ySTD_red ySTD_cross];
            end

        case 'sliding window STD'
            FCS_mat = [y_green y_red y_cross];
            shift1=[FCS_mat(2:end,:); 0 0 0];
            shift2=[shift1(2:end,:); 0 0 0];
            shift3=[shift2(2:end,:); 0 0 0];
            shift4=[shift3(2:end,:); 0 0 0];
            ySTD_green=std([FCS_mat(:,1) shift1(:,1) shift2(:,1) shift3(:,1) shift4(:,1)],0,2);
            ySTD_red=std([FCS_mat(:,2) shift1(:,2) shift2(:,2) shift3(:,2) shift4(:,2)],0,2);
            ySTD_cross=std([FCS_mat(:,3) shift1(:,3) shift2(:,3) shift3(:,3) shift4(:,3)],0,2);
            %calculate std with a 5-data-point window along FCS
    end

if equipmentID==3    
    t=t*0.001; %MaRS FCS has x-axis in ms
    % y_green=DATA(:,FCS_col1);
    % y_green=y_green';
    if ~isempty(strfind(HeaderText{FCS_col1},'10{^-3}')) 
        %HeaderText is a cell array, "{}" retrieves the content. 
        y_green=y_green/1000;
     end
    % y_red=DATA(:,FCS_col2);
    % y_red=y_red';
    if ~isempty(strfind(HeaderText{FCS_col2},'10{^-3}'))
        y_red=y_red/1000;
    end
    % ySTD_red=sqrt(abs(y_red)+eps(y_red));
    % y_cross=DATA(:,FCS_col3);
    % y_cross=y_cross';
    if ~isempty(strfind(HeaderText{FCS_col3},'10{^-3}'))
        y_cross=y_cross/1000;
    end
end

%% How we combine to get global fitting 

ystd=[ySTD_green' ySTD_red' ySTD_cross'];

% testttt
% % % % % if nnz(~isnan(ySTD1))==0
% % % % %     %this is the case where STD is all NaN
% % % % %     %perform coded
% % % % %     disp('all NAN, STD replaced')
% % % % %     % Find Data
% % % % %     try
% % % % %         [FileName,PathName] = uigetfile('*.txt','Select the data file w std', 'C:\Users\LabUser\Dropbox\Sic1-Cdc4 projects\Analysis\FCS\May 29 2014\');
% % % % %         % Read the file into matrix
% % % % %         fid = fopen(strcat(PathName,FileName));
% % % % %         DATA=textscan(fid,format,'headerlines',hl);
% % % % %         ySTD1=DATA{8}; %H
% % % % %         ySTD1=ySTD1';
% % % % %     catch
% % % % %         ySTD1=ones(1,length(ySTD1)); %replace all NaNs with ones
% % % % %     end
% % % % % end

%% Fitting Model Selection
try
    modell=varargin{5};
catch
    fbut = figure('Name','Fitting Model','NumberTitle','off','Position',[100 100 310 500]);
    % Create the button group.
    % hbut = uibuttongroup('Parent',fbut,'visible','on','Position',[20 20 530 480]);
    hbut = uibuttongroup('Position',[0 0 1 1], 'Units','Normalized');
    % Create three radio buttons in the button group.
    u0 = uicontrol('Style','radiobutton','String','3D anomalous',...
        'Units','Normalized','pos',[.1 0.9 0.9 0.08],'parent',hbut,'HandleVisibility','off','Tag','1');
    u1 = uicontrol('Style','radiobutton','String','2D anomalous',...
        'Units','Normalized','pos',[.1 0.8 0.9 0.08],'parent',hbut,'HandleVisibility','off','Tag','2');
    u2 = uicontrol('Style','radiobutton','String','3D anomalous 2-component',...
        'Units','Normalized','pos',[.1 0.7 0.9 0.08],'parent',hbut,'HandleVisibility','off','Tag','3');
    u3 = uicontrol('Style','radiobutton','String','2D anomalous 2-component',...
        'Units','Normalized','pos',[.1 0.6 0.9 0.08],'parent',hbut,'HandleVisibility','off','Tag','4');
    u4 = uicontrol('Style','radiobutton','String','3DA2comp share D2',...
        'Units','Normalized','pos',[.1 0.5 0.9 0.08],'parent',hbut,'HandleVisibility','off','Tag','5');
    u5 = uicontrol('Style','radiobutton','String','3DA2comp share D1D2',...
        'Units','Normalized','pos',[.1 0.4 0.9 0.08],'parent',hbut,'HandleVisibility','off','Tag','6');
    u6 = uicontrol('Style','radiobutton','String','(modify code for more)',...
        'Units','Normalized','pos',[.1 0.3 0.9 0.08],'parent',hbut,'HandleVisibility','off','Tag','7');
    % Initialize some button group properties.
    set(hbut,'SelectionChangeFcn',@selcbk);
    set(hbut,'SelectedObject',[]);  % No selection
    set(fbut,'Visible','on');
    set(hbut,'Visible','on');
    waitfor(fbut) %do not excecute anymore code until fbut has been closed
end

%% Overlap Volume Correctioin Factor
ovcf = [1 1];
try
    ovcf(1) = varargin{7}(1);
    ovcf(2) = varargin{7}(2);
catch
    prompt = {'OVCF green, DNA G0r/G0x:','OVCF red, DNA G0g/G0x'};
    dlg_title = 'Input OVCF values from dual color calib. sample';
    input_OVCFs = inputdlg(prompt, dlg_title, 1, {'1','1'});
    ovcf(1) = str2num(input_OVCFs{1});
    ovcf(2) = str2num(input_OVCFs{2});
end
y_green = y_green ./ ovcf(2); 
y_red = y_red ./ ovcf(1);
y=[y_green' y_red' y_cross'];
%% initial guesses, fixing parameters and lowerbound/upperbound constraints
% model=3; %model =1 gives calibration for volumes, model=2 gives simple diffusion, model=3 gives two component
molar=10; %in nM
try
    disp('Using previous calibration w_green, w_red, s_green, and s_red')
    w=varargin{1}; %in nm
    w_g=w(1);
    w_r=w(2);
    w_x=min(w);
    s=varargin{2};
    s_g=s(1);
    s_r=s(2);
    s_x=min(s);
catch
    %lets FCSfitter run without running calibration by using this w,s if none is given.
    disp('Using default w_green, w_red, s_green, and s_red')
    if (modell==2) || (modell==4) %2D diffusion
        s = 1;
    else
        s = 8;
    end
    w = 250;
    w_g=w;
    w_r=w;
    w_x=w;
    s_g=s;
    s_r=s;
    s_x=s;
end

%make a good guess at concentration
Veff_green=((pi)^(3/2))*((w_g*10^(-9))^(3))*s_g; %in m^3
Veff_red=((pi)^(3/2))*((w_r*10^(-9))^(3))*s_r;
Veff_cross=((pi)^(3/2))*((w_x*10^(-9))^(3))*s_x;

Veff_green=Veff_green*10^(3); %now in L
Veff_red=Veff_red*10^(3);
Veff_cross=Veff_cross*10^(3);

G0_green=mean(y_green(t<5E-5 & t>1E-5));
G0_red=mean(y_red(t<5E-5 & t>1E-5));
G0_cross=mean(y_cross(t<5E-5 & t>1E-5));

% Neff=1./[G0_green G0_red G0_cross]; %in molecules
% Na=6.022E23; %molecules/mol avagadroes number
% Neff=Neff/Na; %now in mol
% molar=(Neff./Veff)*10^(9) %concentration in (mol/L)*10E-9= nM

%make good guess at td
t_1us = find(t>1e-6,1);
[~,ind_td]=min(abs(y_green(t_1us:end)-(G0_green/2))); %find index of FCS3 value closest to one half G(0)
temp=t;
td_green=temp(t_1us+ind_td);
td_green=td_green/1E-6; %now in microseconds

[~,ind_td]=min(abs(y_red(t_1us:end)-(G0_red/2))); %find index of FCS3 value closest to one half G(0)
td_red=temp(t_1us+ind_td);
td_red=td_red/1E-6; %now in microseconds

[~,ind_td]=min(abs(y_cross(t_1us:end)-(G0_cross/2))); %find index of FCS3 value closest to one half G(0)
td_cross=temp(t_1us+ind_td);
td_cross=td_cross/1E-6; %now in microseconds

% td=100; %td~50 for Att488

D_green = (w_g^2)/(400*td_green); %converting um2/s to 10^-6cm2/s
D_red = (w_r^2)/(400*td_red);
D_cross = (w_x^2)/(400*td_cross);
% D2_green = D_green/5;
% D2_red = D_red/5;
% D2_cross = D_cross/5;

G0=[G0_green G0_red G0_cross];
w= [w_g w_r w_x];
s = [s_g s_r s_x];
frac1=[0.5 0.5 0];
D= [D_green D_red D_cross];
D2=D/5;
a = 1;
Tt = [5 5 10];
Tf = [0 0 0];
ginf = [0 0 0];

figure;
hold all
semilogx(t,y_green,'-g','LineWidth',lwthick)
semilogx(t,y_red,'-r','LineWidth',lwthick)
semilogx(t,y_cross,'-k','LineWidth',lwthick)
set(gca,'XScale','log')
ylim([0 max(G0)*1.5])
xlim([5E-7 1])

if modell==1 %user chose crosscor 3d anom
    name={'G0_g' 'G0_r' 'G0_x' 'w_g [nm]' 'w_r [nm]' 'w_x [nm]' 's_g' 's_r' 's_x'...
        'D_g [10^{-6}cm^{2}/s]' 'D_r [10^{-6}cm^{2}/s]' 'D_x [10^{-6}cm^{2}/s]' ...
        'a' 'Tt_g [\mus]' 'Tt_r [\mus]' 'Tt_x [\mus]' 'Tf_g' 'Tf_r' 'Tf_x' ...
        'g_{inf,g}' 'g_{inf,r}' 'g_{inf,x}'}; %The dollar signs '$' are removed by Yuchong for his OCD
    modelParam0=[G0 w s D a Tt Tf ginf];%this is already 3X length
    fixParam=[0 0 0 1 1 1 1 1 1 0 0 0 0 1 1 1 1 1 1 1 1 1]; 
    fixParam=logical(fixParam); %make sure its logical so it can be used for indexing
    %   nParam=length(modelParam0)-nnz(fixParam); %number of free parameters
    lb=zeros(1, length(fixParam)); %lower bounds
    lb(fixParam)=modelParam0(fixParam);
    ub=Inf(1, length(fixParam)); %upper bounds
    ub(fixParam)=modelParam0(fixParam)+eps(modelParam0(fixParam));
    
elseif modell==2 %user chose crosscorr 2d anom
    name={'G0_g' 'G0_r' 'G0_x' 'w_g [nm]' 'w_r [nm]' 'w_x [nm]' 's_g' 's_r' 's_x'...
        'D_g [10^{-6}cm^{2}/s]' 'D_r [10^{-6}cm^{2}/s]' 'D_x [10^{-6}cm^{2}/s]' ...
        'a' 'Tt_g [us]' 'Tt_r [us]' 'Tt_x [us]' 'Tf_g' 'Tf_r' 'Tf_x' ...
        'g_{inf,g}' 'g_{inf,r}' 'g_{inf,x}'}; %The dollar signs '$' are removed by Yuchong for his OCD
    modelParam0=[G0 w s D a(1) Tt Tf ginf];
    fixParam=[0 0 0 1 1 1 1 1 1 0 0 0 0 0 0 1 0 0 1 1 1 1];
    fixParam=logical(fixParam); %make sure its logical so it can be used for indexing
    lb=zeros(1, length(fixParam)); %lower bounds
    lb(fixParam)=modelParam0(fixParam);
    ub=[Inf Inf Inf Inf Inf Inf Inf Inf Inf Inf Inf Inf 2 Inf Inf Inf 1 1 1 1 1 1]; %upper bounds
    ub(fixParam)=modelParam0(fixParam)+eps(modelParam0(fixParam));
    
elseif modell==3 %user chose crosscorr 3d anom 2comp share alpha
    name={'G0_g' 'G0_r' 'G0_x' 'w_g [nm]' 'w_r [nm]' 'w_x [nm]' ...
        's_g' 's_r' 's_x' 'frac1_g' 'frac1_r' 'frac1_x' ...
        'D1_g [10^{-6}cm^{2}/s]' 'D1_r [10^{-6}cm^{2}/s]' 'D1_x [10^{-6}cm^{2}/s]' ...
        'D2_g [10^{-6}cm^{2}/s]' 'D2_r [10^{-6}cm^{2}/s]' 'D2_x [10^{-6}cm^{2}/s]' ...
        'a' 'Tt_g [\mus]' 'Tt_r [\mus]' 'Tt_x [\mus]' 'Tf_g' 'Tf_r' 'Tf_x' ...
        'g_{inf,g}' 'g_{inf,r}' 'g_{inf,x}'};
    modelParam0=[G0 w s frac1 D D2 a(1) Tt Tf ginf];
    fixParam=[0 0 0 1 1 1 1 1 1 0 0 0 0 0 0 0 0 0 1 0 0 1 0 0 1 1 1 1];
    fixParam=logical(fixParam); %make sure its logical so it can be used for indexing
    lb=zeros(1, length(fixParam)); %lower bounds
    lb(fixParam)=modelParam0(fixParam);
    ub=[Inf Inf Inf Inf Inf Inf Inf Inf Inf 1 1 1 Inf Inf Inf Inf Inf Inf 2 Inf Inf Inf 1 1 1 1 1 1]; %upper bounds
    ub(fixParam)=modelParam0(fixParam)+eps(modelParam0(fixParam));
    
elseif modell==4 %user chose crosscorr 2d anomalous 2comp share alpha
    name={'G0_g' 'G0_r' 'G0_x' 'w_g [nm]' 'w_r [nm]' 'w_x [nm]' ...
        's_g' 's_r' 's_x' 'frac1_g' 'frac1_r' 'frac1_x' ...
        'D1_g [10^{-6}cm^{2}/s]' 'D1_r [10^{-6}cm^{2}/s]' 'D1_x [10^{-6}cm^{2}/s]' ...
        'D2_g [10^{-6}cm^{2}/s]' 'D2_r [10^{-6}cm^{2}/s]' 'D2_x [10^{-6}cm^{2}/s]' ...
        'a' 'Tt_g [\mus]' 'Tt_r [\mus]' 'Tt_x [\mus]' 'Tf_g' 'Tf_r' 'Tf_x' ...
        'g_{inf,g}' 'g_{inf,r}' 'g_{inf,x}'};
    modelParam0=[G0 w s frac1 D D2 a(1) Tt Tf ginf];
    fixParam=[0 0 0 1 1 1 1 1 1 0 0 0 0 0 0 0 0 0 1 1 1 1 1 1 1 1 1 1];
    fixParam=logical(fixParam); %make sure its logical so it can be used for indexing
    lb=zeros(1, length(fixParam)); %lower bounds
    lb(fixParam)=modelParam0(fixParam);
    ub=[Inf Inf Inf Inf Inf Inf Inf Inf Inf 1 1 1 Inf Inf Inf Inf Inf Inf 2 Inf Inf Inf 1 1 1 1 1 1]; %upper bounds
    ub(fixParam)=modelParam0(fixParam)+eps(modelParam0(fixParam));
    
elseif modell==5 %user chose crosscorr 3d 2comp anomalous sharing alpha D2
    name={'G0_g' 'G0_r'  'G0_x' 'w_g [nm]' 'w_r [nm]' 'w_x [nm]' ...
        's_g' 's_r' 's_x' 'frac1_g' 'frac1_r' 'frac1_x' ...
        'D1_g [10^{-6}cm^{2}/s]' 'D1_r [10^{-6}cm^{2}/s]' 'D1_x [10^{-6}cm^{2}/s]' ...
        'D2 [10^{-6}cm^{2}/s]' 'a' 'Tt_g [\mus]' 'Tt_r [\mus]' 'Tt_x [\mus]' 'Tf_g' 'Tf_r' 'Tf_x' ...
        'g_{inf,g}' 'g_{inf,r}' 'g_{inf,x}'};
    modelParam0=[G0 w s frac1 D min(D2) a(1) Tt Tf ginf];
    fixParam=[0 0 0 1 1 1 1 1 1 0 0 1 0 0 0 0 1 1 1 1 1 1 1 1 1 1]; %Yuchong doesn't know how to generate this automatically
    fixParam=logical(fixParam); %make sure its logical so it can be used for indexing
    lb=zeros(1, length(fixParam)); %lower bounds
    lb(fixParam)=modelParam0(fixParam);
    ub=[Inf Inf Inf Inf Inf Inf Inf Inf Inf 1 1 1 Inf Inf Inf Inf 2 Inf Inf Inf 1 1 1 1 1 1]; %upper bounds
    ub(fixParam)=modelParam0(fixParam)+eps(modelParam0(fixParam));
    
elseif modell==6 %user chose crosscorr 3d 2comp anomalous sharing alpha D1 and D2
    name={'G0_g' 'G0_r' 'G0_x' 'w_g [nm]' 'w_r [nm]' 'w_x [nm]' ...
        's_g' 's_r' 's_x' 'frac1_g' 'frac1_r' 'frac1_x' ...
        'D1 [10^{-6}cm^{2}/s]' 'D2 [10^{-6}cm^{2}/s]' 'alpha' ...
        'Tt_g [\mus]' 'Tt_r [\mus]' 'Tt_x [\mus]' 'Tf_g' 'Tf_r' 'Tf_x' ...
        'g_{inf,g}' 'g_{inf,r}' 'g_{inf,x}'};
    modelParam0=[G0 w s frac1 max(D) min(D2) a(1) Tt Tf ginf];
    fixParam=[0 0 0 1 1 1 1 1 1 0 0 0 0 0 1 0 0 1 0 0 1 1 1 1]; %Yuchong doesn't know how to generate this automatically
    fixParam=logical(fixParam); %make sure its logical so it can be used for indexing
    lb=zeros(1, length(fixParam)); %lower bounds
    lb(fixParam)=modelParam0(fixParam);
    ub=[Inf Inf Inf Inf Inf Inf Inf Inf Inf 1 1 1 Inf Inf 2 Inf Inf Inf 1 1 1 1 1 1]; %upper bounds
    ub(fixParam)=modelParam0(fixParam)+eps(modelParam0(fixParam));
end

%% UI Table for fitting

f = figure('Name','Fitting Parameters and fixing','NumberTitle','off','Menu','none'); %,'Position',[200 200 550 500]
set(f,'CloseRequestFcn',@my_closefcn) %give it a new closing function that will update table values on close of figure

col1 = name'; %param column
col2 = num2cell(modelParam0)'; %value column
col3 = num2cell(logical(fixParam))'; %fix?
col4 = repmat({'-'},size(col3)); %error column
col5 = repmat({'-'},size(col3)); %dependency column
col6 = num2cell(lb)'; %lb
col7 = num2cell(ub)'; %ub

dat=[col1 col2 col3 col4 col5 col6 col7]; %assemble for table

columnformat = {'char', 'numeric', 'logical', 'numeric' 'numeric' 'numeric' 'numeric'};
cnames = {'Param.','Value','Fix?','SD.','Dep.','lb','ub'};
columneditable =  [true true true true true true true];
t1 = uitable('Parent',f,'Data',dat,'ColumnName',cnames,...
    'ColumnFormat', columnformat,...
    'ColumnEditable', columneditable,...
    'RowName',[],'Position',[20 20 530 400]); %

%when f is closed, custom close request function updates global variable tabValues
%so wait for f to be deleted before getting the updated tabValues
waitfor(f)

%Get modelParam0 and other table values
% tabValues=get(t,'Data');
modelParam0=cell2mat(tabValues(:,2));
fixParam=cell2mat(tabValues(:,3)); %eg [0 0 0 0 1 0]
fixParam=logical(fixParam); %make sure its logical so it can be used for indexing

lb=cell2mat(tabValues(:,6));
ub=cell2mat(tabValues(:,7));
lb(fixParam)=modelParam0(fixParam);
ub(fixParam)=modelParam0(fixParam)+eps(modelParam0(fixParam));

nParam=length(modelParam0)-nnz(fixParam); %number of free parameters

%% Choose fitting range
xpos1 = find(t>1e-5 , 1);
xpos2 = find(t>2 , 1);
% figure;
% hold all
% semilogx(t,y_green,'-g','LineWidth',lwthick)
% semilogx(t,y_red,'-r','LineWidth',lwthick)
% semilogx(t,y_cross,'-k','LineWidth',lwthick)
% set(gca,'XScale','log')
% xlim([5E-7 2])
% ylim([0 max(G0)*1.5])
% h = msgbox('Please select a fitting range');
% uiwait(h);
% [getx, ~] = ginput(2);
% [~,xpos1]=min(abs(t-getx(1))); %find closest t values
% [~,xpos2]=min(abs(t-getx(2)));
if isempty(xpos1)
    xpos1 = 1;
end
if isempty(xpos2)
    xpos2 = length(t);
end

%% Fitting Preamble

%Solver properties
maxiter=1000;
maxfunevals=5000;
tolfun=1e-12; % tolerance for change in fitted func
tolx=1e-12; %tolerance for change in parameters
lsqOpt=[maxiter maxfunevals tolfun tolx];

%% Call the solver

[modelParam,stdp,dep,redchi,res,logEntry] = FCSModelsThreeCurve(t,y,ystd,modelParam0,fixParam,xpos1,xpos2,lsqOpt,nParam,lb,ub,modell);
modelParam;
stdp;
logEntry
x=t(xpos1:xpos2); %too lazy to re-write equations with t instead of x

%generate the curves of best fits from modelParam
if modell==1 %3DA
    G0=modelParam(1:3);
    w=modelParam(4:6);
    s=modelParam(7:9);
    D=modelParam(10:12);
    a=modelParam(13);
    Tt=modelParam(14:16);
    Tf=modelParam(17:19);
    ginf=modelParam(20:22);
    
    myModel=[];
    for j=1:length(G0)
        diffxya=(1+ (x*(10^8)*4*D(j)/(w(j)^2)).^a ).^(-1);
        diffza=(1+ (x*(10^8)*4*D(j)/(w(j)^2)/s(j)^2).^a ).^(-0.5);
        trip1=(1+(Tf(j)/(1-Tf(j))).*exp(-x*(10^6)/Tt(j)));
        myModel=[myModel (G0(j)*diffxya.*diffza.*trip1+ginf(j))];
    end
    
elseif modell==2 %2DA
    G0=modelParam(1:3);
    w=modelParam(4:6);
    s=modelParam(7:9);
    D=modelParam(10:12);
    a=modelParam(13);
    Tt=modelParam(14:16);
    Tf=modelParam(17:19);
    ginf=modelParam(20:22);
    
    myModel=[];
    for j=1:length(G0)
        diffxa=(1+ (x*(10^8)*4*D(j)/(w(j)^2)).^a ).^(-0.5);
        diffyza=(1+ (x*(10^8)*4*D(j)/(w(j)^2)/s(j)^2).^a ).^(-0.5);
        trip1=(1+(Tf(j)/(1-Tf(j))).*exp(-x*(10^6)/Tt(j)));
        myModel=[myModel (G0(j)*diffxa.*diffyza.*trip1+ginf(j))];
    end
    
elseif modell==3 %3DA2comp
    G0=modelParam(1:3);
    w=modelParam(4:6);
    s=modelParam(7:9);
    frac1=modelParam(10:12);
    D=modelParam(13:15);
    D2=modelParam(16:18);
    a=modelParam(19);
    Tt=modelParam(20:22);
    Tf=modelParam(23:25);
    ginf=modelParam(26:28);
    
    myModel=[];
    for j=1:length(G0)
        diff1xya=(1+ (x*(10^8)*4*D(j)/(w(j)^2)).^a ).^(-1);
        diff1za=(1+ (x*(10^8)*4*D(j)/(w(j)^2)/s(j)^2).^a ).^(-0.5);
        diff2xya=(1+ (x*(10^8)*4*D2(j)/(w(j)^2)).^a ).^(-1);
        diff2za=(1+ (x*(10^8)*4*D2(j)/(w(j)^2)/s(j)^2).^a ).^(-0.5);
        trip1=(1+(Tf(j)/(1-Tf(j))).*exp(-x*(10^6)/Tt(j)));
        myModel=[myModel (G0(j)* ((frac1(j)*diff1xya.*diff1za)+((1-frac1(j))*diff2xya.*diff2za)).*trip1 + ginf(j))];
    end
    
elseif modell==4 %2DA2comp
    G0=modelParam(1:3);
    w=modelParam(4:6);
    s=modelParam(7:9);
    frac1=modelParam(10:12);
    D=modelParam(13:15);
    D2=modelParam(16:18);
    a=modelParam(19);
    Tt=modelParam(20:22);
    Tf=modelParam(23:25);
    ginf=modelParam(26:28);
    
    myModel=[];
    for j=1:length(G0)
        diff1xa=(1+ (x*(10^8)*4*D(j)/(w(j)^2)).^a ).^(-0.5);
        diff1yza=(1+ (x*(10^8)*4*D(j)/(w(j)^2)/s(j)^2).^a ).^(-0.5);
        diff2xa=(1+ (x*(10^8)*4*D2(j)/(w(j)^2)).^a ).^(-0.5);
        diff2yza=(1+ (x*(10^8)*4*D2(j)/(w(j)^2)/s(j)^2).^a ).^(-0.5);
        trip1=(1+(Tf(j)/(1-Tf(j))).*exp(-x*(10^6)/Tt(j)));
        myModel=[myModel (G0(j) * ((frac1(j)*diff1xa.*diff1yza)+((1-frac1(j))*diff2xa.*diff2yza)) .*trip1 + ginf(j))];
    end
    
elseif modell==5 %3DA2comp sharing D2
    G0=modelParam(1:3);
    w=modelParam(4:6);
    s=modelParam(7:9);
    frac1=modelParam(10:12);
    D=modelParam(13:15);
    D2=modelParam(16);
    a=modelParam(17);
    Tt=modelParam(18:20);
    Tf=modelParam(21:23);
    ginf=modelParam(24:26);
    
    myModel=[];
    for j=1:length(G0)
        diff1xya=(1+ (x*(10^8)*4*D(j)/(w(j)^2)).^a ).^(-1);
        diff1za=(1+ (x*(10^8)*4*D(j)/(w(j)^2)/s(j)^2).^a ).^(-0.5);
        diff2xya=(1+ (x*(10^8)*4*D2/(w(j)^2)).^a ).^(-1);
        diff2za=(1+ (x*(10^8)*4*D2/(w(j)^2)/s(j)^2).^a ).^(-0.5);
        trip1=(1+(Tf(j)/(1-Tf(j))).*exp(-x*(10^6)/Tt(j)));
        myModel=[myModel (G0(j)* ((frac1(j)*diff1xya.*diff1za)+((1-frac1(j))*diff2xya.*diff2za)).*trip1 + ginf(j))];
    end
    
elseif modell==6 %3DA2comp sharing D1D2
    G0=modelParam(1:3);
    w=modelParam(4:6);
    s=modelParam(7:9);
    frac1=modelParam(10:12);
    D=modelParam(13);
    D2=modelParam(14);
    a=modelParam(15);
    Tt=modelParam(16:18);
    Tf=modelParam(19:21);
    ginf=modelParam(22:24);
    
    myModel=[];
    for j=1:length(G0)
        diff1xya=(1+ (x*(10^8)*4*D/(w(j)^2)).^a ).^(-1);
        diff1za=(1+ (x*(10^8)*4*D/(w(j)^2)/s(j)^2).^a ).^(-0.5);
        diff2xya=(1+ (x*(10^8)*4*D2/(w(j)^2)).^a ).^(-1);
        diff2za=(1+ (x*(10^8)*4*D2/(w(j)^2)/s(j)^2).^a ).^(-0.5);
        trip1=(1+(Tf(j)/(1-Tf(j))).*exp(-x*(10^6)/Tt(j)));
        myModel=[myModel (G0(j)* ((frac1(j)*diff1xya.*diff1za)+((1-frac1(j))*diff2xya.*diff2za)).*trip1 + ginf(j))];
    end
end

res(isnan(res))=0;
res(isinf(res))=0;
res=real(res);

t_range = t(xpos1:xpos2); %t was a row, y was a column, yfit and res were rows...
L_1curve = length(t_range);
% res_green = res(1 : L_1curve);
% res_red = res(1+L_1curve : 2*L_1curve);
% res_cross = res(1+2*L_1curve : 3*L_1curve);
fit_struct(1) = struct('name','green', 'y',y_green(xpos1:xpos2), 'yfit',myModel(1:L_1curve)', 'res',res(1:L_1curve)');
fit_struct(2) = struct('name','red', 'y',y_red(xpos1:xpos2), 'yfit',myModel(L_1curve+1:2*L_1curve)', 'res',res(L_1curve+1:2*L_1curve)');
fit_struct(3) = struct('name','cross', 'y',y_cross(xpos1:xpos2), 'yfit',myModel(2*L_1curve+1:end)', 'res',res(2*L_1curve+1:end)');

figure
hold all
scatter(t_range,fit_struct(1).y,'s','g');
scatter(t_range,fit_struct(2).y,'o','r');
scatter(t_range,fit_struct(3).y,'x','k');
plot(t_range,fit_struct(1).yfit,'g','LineWidth',lwthick);
plot(t_range,fit_struct(2).yfit,'r','LineWidth',lwthick);
plot(t_range,fit_struct(3).yfit,'k','LineWidth',lwthick);
set(gca,'XScale','log');
axis tight
hold off


%% Warnings
% if tt<1
%     %we start fitting at 1E-6 usually so <1 does not make sense
%     warningstring=sprintf('Triplet time is less than 1 microsecond, tt = %f \r\n Fix Tr to 0',tt)
%     h = warndlg(warningstring,'Bad fit')
%     uiwait(h)
% end
% if Tr+Tr2>=1
%     %triplet fractions describe populations
%     warningstring=sprintf('Triplet fraction 1 + Triplet fraction 2 is greater than or equal to 1\r\n Tr+Tr2 = %f',(Tr+Tr2))
%     h = warndlg(warningstring,'Bad fit?')
%     uiwait(h)
% end
% if tt>=td||tt2>td
%     warningstring=sprintf('One or more triplet times are greater than diffusion times \r\n Largest tt = %f',max(tt,tt2))
%     h = warndlg(warningstring,'Bad fit?')
%     uiwait(h)
% end
% if max(td,td2)/min(td,td2)<1.6
%     warningstring=sprintf('Diffusion times are not well seperated (must be >=1.6 Vogel Biophys J. 1999) \r\n ratio = %f',(max(td,td2)/min(td,td2)))
%     h = warndlg(warningstring,'Bad fit?')
%     uiwait(h)
% end

%% For binding studies
%
% %Expected results from theory
% MWSic1=10;% kDA
% MWWD40=40; %
% [Ratio,TauComplex]=RatioCalc(MWSic1,MWWD40,td);
% disp('                ')
% disp('                ')
% disp('                ')
% disp('For binding studies:')
% theorymsg=sprintf('The complex should diffuse %f times slower with tdComplex= %f',1/Ratio, TauComplex)

%% Analysis of Residuals
for j=1:3
    resj=fit_struct(j).res;
    [muhatx,sigmahatx] = normfit(resj);
    [h_x,p_x,stats_x] = runstest(resj,'ud','alpha',0.05);
    [p2_x,h2_x,stats2_x] = signtest(resj,0,'alpha',0.05);
    [h3_x,p3_x]=lillietest(resj);
    
    str_normfitx=sprintf('Gaussian fit \r\n mu = %f sigma = %f', muhatx,sigmahatx);
    
    if h_x==0
        %residuals are non-random
        runpassfailx='PASS';
    else
        %reject null hypothesis that values of residuals come in random order
        runpassfailx='FAIL';
    end
    str_runstestx=sprintf('Runs Test (Random?) \r\n %s \r\n p-value: %f \r\n nruns: %f \r\n n(+): %f \r\n n(-): %f \r\n z statistic: %f',runpassfailx,p_x,stats_x.nruns,stats_x.n1,stats_x.n0,stats_x.z);
    
    if h2_x==0
        %Fails to reject null hypothesis of zero median
        signpassfailx='PASS';
    else
        %Rejects null hypothesis of zero median
        signpassfailx='FAIL';
    end
    
    str_signtestx=sprintf('Sign Test (Zero median?) \r\n %s \r\n p-value: %f \r\n test statistic: %f \r\n z statistic: %f',signpassfailx,p2_x,stats2_x.sign,stats2_x.zval);
    
    if h3_x==0
        %Fails to reject null hypothesis
        lilliepassfailx='PASS';
    else
        %Rejects null hypothesis that residuals come from normal family
        lilliepassfailx='FAIL';
    end
    
    str_lillietestx=sprintf('Lilliefors Test (Normally Distributed?) \r\n %s \r\n p-value: %f',lilliepassfailx,p3_x);
    
    logresx=sprintf('Perpendicular Channel Residual Analysis \r\n \r\n %s \r\n \r\n %s \r\n \r\n %s \r\n \r\n %s',str_normfitx,str_runstestx,str_signtestx,str_lillietestx);
    
    txtbox=sprintf('%s \r\n %s \r\n %s \r\n %s',logEntry,logresx);
    
    %% Plotting
    hfig=figure('Name', ['Fitting results of ' fit_struct(j).name]);
    clf(hfig)
    hTabGroup = uitabgroup;
    %drawnow;
    tab1 = uitab(hTabGroup, 'title','Measured and fitted curves');
    a1 = axes('parent', tab1);
    cla(a1)
    
    semilogx(t_range,fit_struct(j).y, t_range,fit_struct(j).yfit, 'LineWidth',lwthick)
    legend(a1,'Data','Fit','Location','Best')
    % ylim(a1,[1E-4 1])
    xlim(a1,[t(xpos1) t(xpos2)])
    xlabel(a1,'Lag time (s)')
    ylabel(a1,'Autocorr.')
    
    tab2 = uitab(hTabGroup, 'title','Residuals');
    a2=axes('parent', tab2);
    cla(a2)
    semilogx(t_range,resj)
    line([t(xpos1) t(xpos2)] ,[0 0],'Color','r','LineWidth',lwthick)
    legend('Weighted residuals')
    xlabel(a2,'Lag time (s)')
    ylabel(a2,'weighted residual')
    
%    tab3 = uitab(hTabGroup, 'title','Autocorrelation of Residuals');
%    a3=axes('parent', tab3);
%    cla(a3)
%    corp=autom(resj);
%    plot(corp(2:end))
%    xlabel(a3,'lags of residuals')
%    ylabel(a3,'Autocorrelation')
%    title('Autocorrelation of residuals')
    
%    tab4 = uitab(hTabGroup, 'title','Histogram of Residuals');
%    
%    a4=axes('parent', tab4);
%    cla(a4)
%    hist(resj,nhistbin);
%    hp=histfit(resj,nhistbin);
%    set(hp(2),'LineWidth',lwthick)
%    title('Histogram of residuals')
    
end

% %% Figure with Table of fit results
% 
% f2 = figure('Name','Fitting Parameters and fixing','NumberTitle','off','Menu','none','Position',[200 200 550 500]);
% 
% col1 = name'; %param column
% col2 = num2cell(modelParam); %value column
% col3 = num2cell(logical(fixParam)); %fix?
% col4 = num2cell(stdp)'; %value column
% col5 = num2cell(dep)';%value column
% col6 = num2cell(lb); %lb
% col7 = num2cell(ub); %ub
% 
% dat=[col1 col2 col3 col4 col5 col6 col7]; %assemble for table
% 
% columnformat = {'char', 'numeric', 'logical', 'numeric' 'numeric' 'numeric' 'numeric'};
% cnames = {'Param.','Value','Fix?','SD.','Dep.','lb','ub'};
% columneditable =  [true true true true true true true];
% t2 = uitable('Parent',f2,'Data',dat,'ColumnName',cnames,...
%     'ColumnFormat', columnformat,...
%     'ColumnEditable', columneditable,...
%     'RowName',[],...
%     'Position',[15 20 530 480]);
% 
% waitfor(f2)

%% Plot final figure. Save things.
hfig2=figure('Name', 'Fitting results');
clf(hfig2)

% Bottom plot, the data and the fits
subplot(2,1,2)
hold on b
scatter(t_range,fit_struct(1).y,'s','g');
scatter(t_range,fit_struct(2).y,'o','r');
scatter(t_range,fit_struct(3).y,'x','k');
hp1=plot(t_range,fit_struct(1).yfit,'g','LineWidth',lwthick);
hp2=plot(t_range,fit_struct(2).yfit,'r','LineWidth',lwthick);
hp3=plot(t_range,fit_struct(3).yfit,'k','LineWidth',lwthick);
legend([hp1,hp2,hp3],'AC Green','AC Red','CC coupled','Location','Best')
ylim([0 1.25*max(myModel)])
xlim([t(xpos1) t(xpos2)])
hAx1=gca;
hXLabel1 = xlabel(hAx1,'\bf $\tau$ (s)','Interpreter','latex');
hYLabel1 = ylabel(hAx1,'\bf G($\tau$)','Interpreter','latex');
set( gca, 'FontName','Helvetica', 'XScale','log');
hold off
% The top plot, the residuals
subplot(2,1,1)
hold on
line([t(xpos1) t(xpos2)] ,[0 0],'Color','r','LineWidth',lwthick)
semilogx(t_range,fit_struct(1).res,'LineWidth',lwthick,'color','g')
semilogx(t_range,fit_struct(2).res,'LineWidth',lwthick,'color','r')
semilogx(t_range,fit_struct(3).res,'LineWidth',lwthick,'color','k')
hold off
ylim([-max(abs(fit_struct(j).res)) max(abs(fit_struct(j).res))])
xlim([t(xpos1) t(xpos2)])
hAx2=gca;
set(hAx2,'XScale','log');
%             hXLabel2 = xlabel(hAx2,'\bf $\tau$ [s]','Interpreter','latex');
hXLabel2 = xlabel(hAx2,'','Interpreter','latex');
hYLabel2 = ylabel(hAx2,'\bf res.','Interpreter','latex');
set( gca, 'FontName'   , 'Helvetica' );

try
    set(hAx1,'YTick', roundn(linspace(0,max(ylim(hAx1)),4),-1))
catch
    try
        set(hAx1,'YTick', roundn(linspace(0,max(ylim(hAx1)),4),-2))
    catch
        set(hAx1,'YColor', [0.1 0.1 0.1])
    end
end
%              set(hAx2,'YTick',[-roundn(max(abs(res)),nr) 0 roundn(max(abs(res)),nr)],'YColor', [0.3 0.3 0.3])
if max(abs(fit_struct(1).res))<1
    set(hAx2,'YTick',[-0.6 0 0.6])
else
    set(hAx2,'YTick',[-2 0 2])
end
set(hAx1,'XTick', [1E-6 1E-5 1E-4 1E-3 1E-2 1E-1])
set(hAx2,'XTick', [1E-6 1E-5 1E-4 1E-3 1E-2 1E-1])

set([hXLabel1, hYLabel1,hXLabel2,hYLabel2], ...
    'FontName'   , 'AvantGarde');

set([hXLabel1, hYLabel1,hXLabel2,hYLabel2]  , ...
    'FontSize'   , 12          );
set(hAx1, ...
    'Box'         , 'on'     , ...
    'TickDir'     , 'in'     , ...
    'TickLength'  , [.02 .02] , ...
    'XMinorTick'  , 'on'      , ...
    'YMinorTick'  , 'on'      , ...
    'YGrid'       , 'off'      , ...
    'XColor'      , [.1 .1 .1], ...
    'YColor'      , [.1 .1 .1], ...
    'LineWidth'   , 2         );
set(hAx2, ...
    'Box'         , 'on'     , ...
    'TickDir'     , 'in'     , ...
    'TickLength'  , [.02 .02] , ...
    'XMinorTick'  , 'on'      , ...
    'YMinorTick'  , 'off'      , ...
    'YGrid'       , 'off'      , ...
    'XColor'      , [.1 .1 .1], ...
    'YColor'      , [.1 .1 .1], ...
    'XTickLabel'  , [], ...
    'LineWidth'   , 2         );
left1=0.15;
left2=left1;
width1=0.8;
width2=width1;
height1=0.65;
height2=0.15;
bottom1=0.12;
bottom2=bottom1+height1+0.03;
% set(hAx1,'Position',[0.08 0.1 0.75 0.55]); %1
% set(hAx2,'Position',[0.08 .68 0.75 .15]); %2
set(hAx1,'Position',[left1 bottom1 width1 height1]); %1
set(hAx2,'Position',[left2 bottom2 width2 height2]); %2

% Ask for saving
button = questdlg('Save presentation quality image','Save?','Yes','Curve data only','Cancel','Yes');
switch button
    case 'Yes'
        save([PathName FileName(1:end-4) '_curves.mat'],'t_range','fit_struct');
        set(gcf, 'PaperPositionMode', 'auto');
        imgname=strcat(PathName,FileName(1:end-4),'.png');
        if ~exist(imgname,'file');
            print('-dpng','-r300',imgname)
        else
            b=questdlg('Do you want to overwrite', 'The file allready exist', 'Yes','No','No');
            switch b
                case 'Yes'
                    print('-dpng','-r300',imgname)
                case 'No'
                    imgname=[imgname(1:end-4) char(39) imgname(end-3:end)]; %add a prime (') to the end of the filename 
                    print('-dpng','-r300',imgname)
            end
        end
        
    case 'No'
        disp('No image saved')
    case 'Cancel'
        disp('No image saved')
end

%user must choose mode
% Construct a questdlg with three options
choice = questdlg('Save table of fits?', 'Fitting Table', 'Tab Dlm','None','Tab Dlm');
% Handle response

switch choice
%     case 'LaTex'
%         %save table
%         tablemaker(name,modelParam,stdp,RhCalc,Dcalc,redchi)
    case 'Tab Dlm'
        %save table
        tablemakerUNFORMAT(name,modelParam,stdp,redchi) %RhCalc and Dcalc were temporarily removed
    case 'None'
        disp('No table')
end



button = questdlg('Keep calib info and fitting model, and find another file?','Continue','Yes');
switch button
    case 'Yes'
        FCSFitterThreeCurve(w,s,PathName,equipmentID,modell,std_method,ovcf,choice_channels)
    case 'No'
        disp('Finished')
    case 'Cancel'
        disp('Finished')
end


    function []=tablemaker(names,modelParamf,stdf,Rh,D,redchisq)
        
        mystring=strcat(PathName,FileName(1:end-4),'_LATEX_TABLE.txt');
        if ~exist(mystring,'file');
            fileID = fopen(mystring,'w');
        else
            z=questdlg('The file already exist. Do you want to overwrite?', ...
                'Yes','No','No');
            switch z
                case 'Yes'
                    fileID = fopen(mystring,'w');
                case 'No'
                    if isnumeric(str2double(mystring(end-4)))
                        apnd2=str2double(mystring(end-4))+1;
                        mystring=strcat(mystring(1:end-5),num2str(apnd2),mystring(end-4:end));
                        disp(mystring)
                    else
                        mystring(end+1)='1';
                        disp(mystring)
                    end
                    
            end
        end
        
        fprintf(fileID,'\\centering \r\n');
        fprintf(fileID,'\\begin{tabular}{ccc} \r\n');
        fprintf(fileID,'\\hline \\bf Param. & \\bf Fit & \\bf Std. \\\\ \r\n \\hline ');
        for i=1:length(modelParamf)
            if modelParamf(i)<1E-13
                fprintf(fileID,'%s & 0  & 0 \\\\ \r\n',names{i});
            elseif stdf(i)==0
                fprintf(fileID,'%s & %.2g  & 0  \\\\ \r\n',names{i},modelParamf(i));
            else
                fprintf(fileID,'%s & %.2g  & %.2g  \\\\ \r\n',names{i},modelParamf(i),stdf(i));
            end
            
        end
        if length(Rh)==1
            fprintf(fileID,'\\hline $R_{h}$ [�] & %.2f  &  \\\\ \r\n',Rh);
            fprintf(fileID,'$D$ & %.2g  &  \\\\ \r\n',D);
        elseif length(Rh)==2
            fprintf(fileID,'\\hline $R_{h1}$ [�] & %.2f  &  \\\\ \r\n',Rh(1));
            fprintf(fileID,'$D_{1}$ & %.2f  &  \\\\ \r\n',D(1));
            fprintf(fileID,'$R_{h2}$ [�] & %.2f  &  \\\\ \r\n',Rh(2));
            fprintf(fileID,'$D_{2}$ & %.2f  &  \\\\ \r\n',D(2));
        end
        fprintf(fileID,'\\hline $\\chi^{2}_{\\nu}$ & %.2g  &  \\\\ \r\n',redchisq);
        fprintf(fileID,'\\hline \r\n');
        fprintf(fileID,'\\end{tabular}  \r\n');
        
        fclose(fileID);
        
    end

    function []=tablemakerUNFORMAT(names,modelParamf,stdf,redchisq)
        
        %         mystring=strcat(FileName(1:end-4),'_TABLE.txt');
        %         fileID = fopen(strcat(PathName,mystring),'w');
        
        mystring=strcat(PathName,FileName(1:end-4),'_TABLE.txt');
        if ~exist(mystring,'file');
            fileID = fopen(mystring,'w');
        else
            z=questdlg('Do you want to overwrite?', 'File already exists','Yes','No, auto rename','Cancel saving','No, auto rename');
            switch z
                case 'Yes'
                    fileID = fopen(mystring,'w');
                case 'No, auto rename'
                    if isnumeric(str2double(mystring(end-4)))&& ~isnan(str2double(mystring(end-4)))
                        apnd2=str2double(mystring(end-4))+1;
                        mystring(end-4)=num2str(apnd2);
                        fileID = fopen(mystring,'w');
                    else
                        mystring=strcat(mystring(1:end-4),'1',mystring(end-3:end));
                        fileID = fopen(mystring,'w');
                    end
                    
            end
        end
        
        fprintf(fileID,'Param.\tFit\tStd.\r\n');
        for i=1:length(modelParamf)
            if modelParamf(i)<1E-13 %this parameter was likely fixed around 0
                fprintf(fileID,'%s\t0\t0\r\n',names{i});
            elseif stdf(i)==0 %this paramater was fixed
                fprintf(fileID,'%s\t%.3g\t0\r\n',names{i},modelParamf(i));
            else %normal writing
                fprintf(fileID,'%s\t%.3g\t%.2f\r\n',names{i},modelParamf(i),stdf(i));
            end
            
        end
        %         if length(Rh)==1
        %             fprintf(fileID,'R_{h}\t%.2f\r\n',Rh);
        %             fprintf(fileID,'D\t%.2f\r\n',D);
        %         elseif length(Rh)==2
        %             fprintf(fileID,'R_{h1}\t%.2f\r\n',Rh(1));
        %             fprintf(fileID,'D_{1}\t%.2f\r\n',D(1));
        %             fprintf(fileID,'R_{h2}\t%.2f\r\n',Rh(2));
        %             fprintf(fileID,'D_{2}\t%.2f\r\n',D(2));
        %         end
        fprintf(fileID,'chi^{2}\t%.2f\r\n',redchisq);
        fclose(fileID);
        
    end

    function [Rh]=rotCorCalc(D,T)
        D=D*1E-6; %D is now in cm^2/s
        D=D/(100*100); %D is now in m^2/s
        k=1.3807E-23;%Boltzman constant J/K
        %eta=1; %the viscosity in cP;
        T=T+273.15; %T in Kelvin
        A=2.414E-5; %Pa*S
        B=247.8;
        C=140;
        eta=A*10^(B/(T-C)); %Pa*s
        eta=1.05;
        eta=eta*10^(-3); %convert to Pa*s
        %T=25; %temperature in celsius
        
        
        Rh=k*T/(6*pi*eta*D);
        %J/(Pa*s*m^2/s)=J/(Pa*m^2)={N*m}/({N/m^2}*m^2)=N*m/N=m
        
        Rh=Rh/(1E-10); %from m to angstrom
        
    end

    function [Ratio,TauComplex]=RatioCalc(MW1,MW2,TauFree)
        
        %MW1= free ligand
        %MW2= Free substrate
        
        MWComplex=MW1+MW2;
        Ratio=(MW1/MWComplex)^(1/3);
        TauComplex=TauFree/Ratio;
        
        
    end

    function my_closefcn(src,evnt)
        % User-defined close request function
        % to update tabValues global variable
        
        tabValues=get(t1,'Data');
        delete(gcf)
        
    end

    function selcbk(source,eventdata)
        %         disp(source);
        %         disp([eventdata.EventName,'  ',...
        %             get(eventdata.OldValue,'String'),'  ', ...
        %             get(eventdata.NewValue,'String')]);
        disp('Model:')
        disp(get(get(source,'SelectedObject'),'String'));
        modell=str2double(get(get(source,'SelectedObject'),'Tag'));
    end

end